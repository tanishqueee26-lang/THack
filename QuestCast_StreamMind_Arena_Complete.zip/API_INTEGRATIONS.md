# API and integration contracts

## Local endpoints

- Frontend origin: `http://localhost:3000`
- Backend origin: `http://localhost:8011`
- Health: `GET /health`
- OpenAPI: `GET /docs`

## Twitch authorization

The backend uses Twitch's authorization-code grant flow. `TWITCH_REDIRECT_URI` must exactly match the OAuth Redirect URL registered in the selected Twitch Developer application. For the default local setup, both are:

`http://localhost:8011/auth/callback`

The app stores tokens encrypted with Fernet and exposes only creator identity/status to the browser. OAuth state is random, stored in an HttpOnly cookie, and compared on callback. The backend validates tokens with Twitch and refreshes when needed.

Official docs:
- OAuth authorization-code flow: https://dev.twitch.tv/docs/authentication/getting-tokens-oauth/
- EventSub WebSocket handling: https://dev.twitch.tv/docs/eventsub/handling-websocket-events/
- EventSub WebSocket reference: https://dev.twitch.tv/docs/eventsub/websocket-reference/
- Chat authentication and EventSub: https://dev.twitch.tv/docs/chat/authenticating/
- Helix API reference: https://dev.twitch.tv/docs/api/reference/
- EventSub chat message payload and badge fields: https://dev.twitch.tv/docs/eventsub/eventsub-subscription-types/
- Clip creation and verification behavior: https://dev.twitch.tv/docs/api/reference/#create-clip
- Get Streams and `viewer_count`: https://dev.twitch.tv/docs/api/reference/#get-streams

## EventSub

Local development uses WebSocket transport and a user access token. The app waits for `session_welcome`, reads the session ID and creates subscriptions. It handles notifications, keepalives, reconnect messages, revocations, retries and duplicate message IDs. Webhook transport is optional and requires a public HTTPS callback; its signature is HMAC-SHA256 over message ID + timestamp + raw body, and messages older than ten minutes are rejected.

Implemented subscription types:
- `stream.online`, `stream.offline`
- `channel.raid`
- `channel.follow` (scope-gated)
- `channel.subscribe` (scope-gated)
- `channel.chat.message` (scope-gated)

LIVE chat commands are parsed only from verified `channel.chat.message` notifications. Supported viewer commands: `!join`, `!quest`, `!progress`, and `!leaderboard`. A persisted 5-second per-user/per-command cooldown applies. `!quest start` and `!quest pause` require Twitch moderator or broadcaster badges. Bot replies require the creator's granted `user:write:chat` scope and the shared outbound sender serializes all messages to at most one per second.

## Creator-approved chat breaks

`POST /api/workspace/chat-break/prepare` prepares a bounded playlist of polls and meme moments using the official OpenAI Responses API when `OPENAI_API_KEY` is configured, otherwise curated fallback copy. The creator reviews the complete list before `POST /api/workspace/chat-break/start` schedules it. `GET /api/workspace/chat-break` returns the active activity and poll counts; `POST /api/workspace/chat-break/stop` ends the session. A backend lifespan worker rotates only through the preapproved queue and posts to Twitch via the serialized chat sender. LIVE mode requires `user:read:chat` and `user:write:chat`.

Verified Twitch chat events may vote with `!vote A`, `!vote B`, or `!vote C`. A persisted per-viewer cooldown applies; stored poll votes use a per-poll one-way hash, and the raw chat text is not retained. The active activity and aggregate results are available from the existing OBS overlay state endpoint. Optional GIPHY search runs client-side with `rating=g` when `VITE_GIPHY_API_KEY` is configured; animated GIFs retain GIPHY attribution.

## Scope-to-feature map

| Scope | Feature |
|---|---|
| `user:read:chat` | Receive chat messages through EventSub |
| `user:write:chat` | Send chat messages through Helix |
| `moderator:read:followers` | Follow notifications / follower data where permitted |
| `channel:read:subscriptions` | Subscription notifications / data where permitted |
| `clips:edit` | Create a clip |

The app checks the scopes returned by Twitch token validation. A configured scope string is not proof of granted permissions.

## Live activity and analytics

The shared `SlidingWindow` computes the trailing 60-second weighted activity score consumed by the dashboard and OBS overlay. It is restored from persisted recent workspace events after process restart. The current cache is process-local; use a shared store before running multiple API workers.

The analytics service records event counts by UTC hour and quest completion funnel. A background Helix `/streams` sampler records `viewer_count` once per minute while a connected channel is live. Peak viewers are returned only from those observed samples; no value is invented when sampling data is absent.

## ClipSynth and Twitch clip behavior

The candidate detector stores event timestamps and reasons; it does not access video footage. The creator must approve a candidate before the app attempts Twitch Create Clip From VOD. QuestCast queries the broadcaster's archive videos, matches the candidate timestamp to a VOD, calculates the corresponding `vod_offset`, and submits a 30-second clip request. Twitch documents the VOD clip workflow as asynchronous; QuestCast polls Get Clips for up to 60 seconds and stores a public URL only after the returned ID is present. If no matching VOD is available, the candidate remains in the review queue with an explicit limitation. The VOD workflow requires `channel:manage:clips` or `editor:manage:clips`.

## Moderator roles

Creators grant review-only access by Twitch user ID. Moderators authenticate through their own Twitch OAuth session; the backend verifies a creator-workspace grant before returning candidates or accepting approve/reject actions. Moderator workspace selection is available through `GET /api/workspace/moderator/workspaces`. Moderators cannot create clips or mutate creator settings.

## Workspace API

See `README.md` API table and `/docs` for request/response schemas. All workspace data is partitioned by operating mode and creator key. SIMULATION endpoints reject requests in LIVE mode.

## AI provider

`POST /api/workspace/ai/suggestions` accepts a suggestion kind and supplied context. The configured OpenAI-compatible provider is optional; deterministic local copy suggestions are used otherwise. This API cannot mutate quest state, score, memory facts or review status.


## Timestamp-aligned VOD clips

QuestCast uses Twitch's Create Clip From VOD endpoint (`POST /helix/videos/clips`) for approved timestamped candidates. It queries the creator's archive VODs (`GET /helix/videos?user_id=...&type=archive`), matches the candidate timestamp, calculates `vod_offset`, and verifies the returned clip ID through `GET /helix/clips?id=...`. Required scope: `channel:manage:clips` or `editor:manage:clips`. If no matching VOD is available, the candidate is retained and the failure is shown.

## BotGuard

BotGuard listens for Twitch `channel.suspicious_user.message` and `channel.suspicious_user.update` with `moderator:read:suspicious_users`. Local heuristics look for high message bursts and repeated identical messages. They are review signals, not proof of automation. Optional AI can explain evidence but cannot make decisions. A creator can manually confirm a channel chat ban using `POST /helix/moderation/bans` with `moderator:manage:banned_users`; QuestCast never automatically bans a viewer.


## Streamer-marked moments

The Live Control Room uses Twitch `POST /helix/streams/markers` with `channel:manage:broadcast`. Twitch returns the marker ID, creation time and position in the current stream. QuestCast records this response as a verified `stream.marker` event and feeds it to the normal candidate scoring pipeline. Markers are not simulated in LIVE mode.

## Expansion integrations

- **Twitch Extension:** panel assets in `frontend/extension/`; backend verifies Extension Helper JWTs with the base64 shared secret. This is a developer starter, not a released extension. Required variables: `TWITCH_EXTENSION_SECRET_B64`, `TWITCH_EXTENSION_ORIGIN`.
- **Vision:** opt-in job contract only. A future worker must use creator-authorized VODs, bounded frame sampling, secure temporary storage and a configured multimodal provider. Current status: blocked/unconfigured.
- **Social publishing:** approved clip jobs are persisted, but platform OAuth, upload APIs and verification workers are pending.
- **Gameplay:** sandbox action records only. A custom adapter is required before any real game integration; only allowlisted actions should be exposed.
- **Economy and AI progress:** verified Twitch events can trigger creator-configured fixed rewards/progress rules. The AI layer is explanatory and does not decide facts or invent points.
