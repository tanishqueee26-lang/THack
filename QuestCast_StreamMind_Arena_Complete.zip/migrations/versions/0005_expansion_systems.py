"""Quest economy, branching story and guarded integration job foundations."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect
from backend.db import Base
from backend import workspace, expansion  # noqa: F401

revision = "0005_expansion_systems"
down_revision = "0004_clip_caption_suggestions"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    columns = {c["name"] for c in inspect(bind).get_columns("exp_story_nodes")}
    if "parent_node_id" not in columns:
        op.add_column("exp_story_nodes", sa.Column("parent_node_id", sa.String(36), nullable=True))
    if "parent_choice_key" not in columns:
        op.add_column("exp_story_nodes", sa.Column("parent_choice_key", sa.String(48), nullable=False, server_default=""))
    Base.metadata.create_all(bind=bind, checkfirst=True)

def downgrade():
    # Preserve user-created economy, story and audit history on downgrade.
    pass
