"""Create the complete QuestCast schema from SQLAlchemy metadata.

This initial baseline is idempotent for existing local MVP databases. New schema changes
should be added as normal Alembic revisions after this baseline.
"""
from alembic import op
from backend.db import Base
from backend import workspace  # noqa: F401

revision = "0001_workspace_baseline"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    Base.metadata.create_all(bind=op.get_bind(), checkfirst=True)

def downgrade():
    # Intentionally retain data tables; use an explicit backup/maintenance procedure
    # before any destructive schema rollback in a creator deployment.
    pass
