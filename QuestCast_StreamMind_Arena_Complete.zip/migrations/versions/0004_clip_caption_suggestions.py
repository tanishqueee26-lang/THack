"""Add optional creator-reviewed ClipSynth caption suggestions."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect
from backend.db import Base
from backend import workspace  # noqa: F401

revision = "0004_clip_caption_suggestions"
down_revision = "0003_bot_guard"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    columns = {c["name"] for c in inspect(bind).get_columns("workspace_candidates")}
    if "caption_suggestion" not in columns:
        op.add_column("workspace_candidates", sa.Column("caption_suggestion", sa.Text(), nullable=False, server_default=""))
    Base.metadata.create_all(bind=bind, checkfirst=True)

def downgrade():
    # Keep creator-authored review history; no destructive rollback.
    pass
