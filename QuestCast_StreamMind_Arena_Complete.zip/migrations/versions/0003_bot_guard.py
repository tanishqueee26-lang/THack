"""Add explainable BotGuard review queue."""
from alembic import op
from backend.db import Base
from backend import workspace  # noqa: F401 - register BotReview metadata

revision = "0003_bot_guard"
down_revision = "0002_engagement_analytics"
branch_labels = None
depends_on = None


def upgrade():
    # Forward-only and non-destructive: create the new review table if absent.
    Base.metadata.create_all(bind=op.get_bind(), checkfirst=True)


def downgrade():
    # Keep moderation audit history; do not drop user review records automatically.
    pass
