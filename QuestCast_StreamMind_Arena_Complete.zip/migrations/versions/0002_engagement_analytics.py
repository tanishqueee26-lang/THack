"""Add hype, chat moderation, clip workflow and analytics fields."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect
from backend.db import Base
from backend import workspace  # noqa: F401

revision = "0002_engagement_analytics"
down_revision = "0001_workspace_baseline"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    columns = {c["name"] for c in inspect(bind).get_columns("workspace_candidates")}
    if "clip_status" not in columns:
        op.add_column("workspace_candidates", sa.Column("clip_status", sa.String(length=24), nullable=False, server_default="not_requested"))
    if "clip_detail" not in columns:
        op.add_column("workspace_candidates", sa.Column("clip_detail", sa.String(length=500), nullable=False, server_default=""))
    if "clip_requested_at" not in columns:
        op.add_column("workspace_candidates", sa.Column("clip_requested_at", sa.DateTime(), nullable=True))
    if "title_suggestion" not in columns:
        op.add_column("workspace_candidates", sa.Column("title_suggestion", sa.String(length=180), nullable=False, server_default=""))
    Base.metadata.create_all(bind=bind, checkfirst=True)

def downgrade():
    # Non-destructive: retain creator data and engagement history.
    pass
