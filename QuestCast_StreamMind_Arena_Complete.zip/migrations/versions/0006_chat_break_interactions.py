"""Creator-approved interactive chat-break activity queue."""
from alembic import op
from backend.db import Base
from backend import chat_breaks  # noqa: F401 - register chat-break tables on Base.metadata

revision = "0006_chat_break_interactions"
down_revision = "0005_expansion_systems"
branch_labels = None
depends_on = None


def upgrade():
    Base.metadata.create_all(bind=op.get_bind(), checkfirst=True)


def downgrade():
    bind = op.get_bind()
    Base.metadata.tables["workspace_chat_break_votes"].drop(bind, checkfirst=True)
    Base.metadata.tables["workspace_chat_break_activities"].drop(bind, checkfirst=True)
    Base.metadata.tables["workspace_chat_breaks"].drop(bind, checkfirst=True)
