from logging.config import fileConfig
import os
from alembic import context
from sqlalchemy import engine_from_config, pool
from backend import config
from backend.db import Base
from backend import workspace, expansion  # noqa: F401 - register existing workspace models on Base.metadata

cfg = context.config
if cfg.config_file_name:
    fileConfig(cfg.config_file_name)
cfg.set_main_option("sqlalchemy.url", config.DATABASE_URL.replace("%", "%%"))
target_metadata = Base.metadata

def run_migrations_offline():
    context.configure(url=config.DATABASE_URL, target_metadata=target_metadata, literal_binds=True,
                      dialect_opts={"paramstyle": "named"}, compare_type=True)
    with context.begin_transaction(): context.run_migrations()

def run_migrations_online():
    connectable = engine_from_config(cfg.get_section(cfg.config_ini_section), prefix="sqlalchemy.",
                                     poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata, compare_type=True)
        with context.begin_transaction(): context.run_migrations()

if context.is_offline_mode(): run_migrations_offline()
else: run_migrations_online()
