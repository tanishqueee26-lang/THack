"""Checks that YOUR deployed webhook endpoint is reachable over HTTPS and enforces signatures.
    python -m scripts.check_webhook      (needs PUBLIC_BASE_URL + TWITCH_EVENTSUB_SECRET in .env)
This does NOT prove Twitch can deliver: for that, register a subscription (log in with EVENT_TRANSPORT=webhook)
and confirm the "EventSub" status turns to webhook-active after a real event (or use `twitch event trigger`)."""
import hashlib
import hmac
import json
import sys
import uuid
from datetime import datetime, timezone

import httpx

from backend import config


def post(url: str, secret: str, mtype: str, body: bytes) -> httpx.Response:
    mid, ts = str(uuid.uuid4()), datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000000000Z")
    sig = "sha256=" + hmac.new(secret.encode(), (mid + ts).encode() + body, hashlib.sha256).hexdigest()
    return httpx.post(url, content=body, timeout=15, headers={
        "Twitch-Eventsub-Message-Id": mid, "Twitch-Eventsub-Message-Timestamp": ts,
        "Twitch-Eventsub-Message-Signature": sig, "Twitch-Eventsub-Message-Type": mtype})


def main() -> int:
    if not config.PUBLIC_BASE_URL.startswith("https://") or not config.EVENTSUB_SECRET:
        print("Set PUBLIC_BASE_URL (https://...) and TWITCH_EVENTSUB_SECRET first.")
        return 2
    url = config.PUBLIC_BASE_URL + "/webhooks/twitch"
    body = json.dumps({"challenge": "qc-check-123"}).encode()
    r1 = post(url, config.EVENTSUB_SECRET, "webhook_callback_verification", body)
    r2 = post(url, "wrong-secret", "webhook_callback_verification", body)
    ok1 = r1.status_code == 200 and r1.text == "qc-check-123"
    ok2 = r2.status_code == 403
    print("PASS" if ok1 else "FAIL", "valid signature -> challenge echoed", r1.status_code)
    print("PASS" if ok2 else "FAIL", "bad signature -> 403", r2.status_code)
    return 0 if ok1 and ok2 else 1


if __name__ == "__main__":
    sys.exit(main())
