"""REAL Twitch verification. Log in through the app first, then (from repo root, with .env filled in):
    python -m scripts.verify_twitch [seconds_to_wait_for_chat]
Nothing is mocked: each step passes only if Twitch actually answered. Exit code 0 = all passed."""
import asyncio
import json
import sys

import websockets

from backend import config, twitch as tw
from backend.db import SessionLocal, User

results: list[bool] = []


def step(name: str, ok: bool, detail: str = "") -> bool:
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")
    return ok


async def main(wait: float) -> int:
    if config.missing_config():
        print("Cannot verify in SIMULATION MODE. Missing:", config.missing_config())
        return 2
    with SessionLocal() as db:
        user = db.query(User).filter(User.access_token_enc != "").first()
        if not user:
            print("No logged-in user in the DB. Open the app and click Connect Twitch first.")
            return 2
        if not step("OAuth token valid (/oauth2/validate)", await tw.validate_and_store(user, db),
                    f"login={user.login} scopes={user.scopes}"):
            return 1
        me = await tw.get_me(user.access_token)
        step("Broadcaster identity (Get Users)", me["id"] == user.twitch_id, me["login"])
        try:
            st = await tw.helix(user, db, "/streams", {"user_id": user.twitch_id})
            step("Stream status (Get Streams)", True, "LIVE" if st["data"] else "offline")
        except tw.TwitchError as e:
            step("Stream status (Get Streams)", False, str(e))
        if "user:read:chat" not in user.scopes.split():
            step("Chat scope granted", False, "reconnect Twitch to grant user:read:chat")
            return 1
        async with websockets.connect(config.EVENTSUB_WS_URL) as ws:
            msg = json.loads(await asyncio.wait_for(ws.recv(), 10))
            if not step("EventSub WebSocket welcome", msg["metadata"]["message_type"] == "session_welcome"):
                return 1
            try:
                status = await tw.create_ws_subscription(user, db, "channel.chat.message", "1",
                    {"broadcaster_user_id": user.twitch_id, "user_id": user.twitch_id}, msg["payload"]["session"]["id"])
                step("Subscribe channel.chat.message", status == "enabled", status)
            except tw.TwitchError as e:
                step("Subscribe channel.chat.message", False, str(e))
                return 1
            print(f">>> Type a message in YOUR Twitch chat now (waiting {wait:.0f}s)...")
            loop, deadline, got = asyncio.get_running_loop(), asyncio.get_running_loop().time() + wait, False
            try:
                while not got:
                    m = json.loads(await asyncio.wait_for(ws.recv(), max(0.1, deadline - loop.time())))
                    got = (m["metadata"]["message_type"] == "notification"
                           and m["payload"]["subscription"]["type"] == "channel.chat.message")
            except asyncio.TimeoutError:
                pass
            step("Received a REAL chat message notification", got)
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main(float(sys.argv[1]) if len(sys.argv) > 1 else 45)))
