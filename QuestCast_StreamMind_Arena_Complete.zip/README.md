# StreamQuest — Play Live. Create Highlights. Keep the Story Going.

**QuestCast turns live participation into creator-approved highlights and a community story that brings viewers back.**

QuestCast combines interactive community quests, creator-reviewed highlight candidates, a persistent community timeline, and an OBS browser-source overlay. This repository is a local-first MVP. Twitch LIVE mode is deliberately separate from the SIMULATION workspace.

## What is implemented

- **Creator command center:** workspace metrics, active quest, recent activity and candidate queue.
- **StreamQuest:** create and manage quests, stages, targets, one active quest per channel, unique participation, persistent progress and completion milestones.
- **Participation:** in SIMULATION, use the control-room viewer simulator. In LIVE, verified Twitch `channel.chat.message` events process `!join`, `!quest`, `!progress`, and `!leaderboard`; moderator/broadcaster badges unlock `!quest start` and `!quest pause`.
- **ClipSynth:** timestamped candidate events, deterministic 60-second scoring, transparent reason breakdown, pending/approved/rejected review states, AI title/caption suggestions and a separate Twitch VOD clip attempt after creator approval. It finds the archive VOD matching the candidate timestamp, calls Create Clip From VOD with the corresponding VOD offset, and verifies the returned ID with Get Clips. A candidate is never labelled a clip until Twitch confirms it.
- **Community Memory:** persistent milestones and approved-highlight entries, chronological timeline, deterministic recap and the next configured quest objective.
- **OBS overlay:** responsive quest/progress/milestone overlay with a preview. LIVE OBS sources can use a private, one-time-displayed overlay token.
- **Chat break mode:** prepare and review a short playlist of polls and G-rated meme moments; the backend rotates approved prompts while the streamer is away. Viewers vote with `!vote A/B/C`, and the live poll or GIPHY GIF appears on the OBS overlay.
- **Live chat engagement coach:** opt-in creator tool batches recent Twitch chat through the already configured `AI_BASE_URL` / `AI_API_KEY` / `AI_MODEL`, surfaces recurring discussion topics and optional streamer prompts, rotates a ping-pong-style suggestion card, and can speak the review using the browser voice. The coach is off by default; names and common direct identifiers are stripped, raw text is kept only in a bounded in-memory queue, and no raw chat is added to the database.
- **AI copy assistant:** optional OpenAI-compatible provider; deterministic local fallback when unconfigured. Drafts highlight titles, captions, recaps and next-quest copy. Suggestions never award progress, score events, or approve candidates.
- **BotGuard:** first-party Twitch suspicious-user EventSub signals plus privacy-minimizing chat burst/repetition heuristics. The review queue shows evidence and risk indicators; AI can explain recorded evidence but cannot decide or execute enforcement. Only a creator can manually confirm a channel chat ban, and Twitch must accept it.
- **Twitch:** server-side authorization-code OAuth, encrypted tokens at rest, EventSub WebSocket integration, webhook signature validation, token validation/refresh, deduplication, creator stream markers, VOD clip creation/verification and creator-confirmed channel moderation.

## Local Windows quick start

Prerequisites: Python 3.12+, Node 20+, npm, and optionally Docker Desktop.

### 1. Configure environment

From the project root in PowerShell:

```powershell
Copy-Item .env.example .env
```

The example starts in `APP_MODE=simulation`, so you can use the complete local demo without Twitch credentials. Keep the sample `TOKEN_ENCRYPTION_KEY` out of production; generate a Fernet key for a real deployment:

```powershell
python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"
```

Put the generated value in `.env`. Do not paste secrets into chat or commit `.env`.

### 2. Start with Docker (recommended)

```powershell
docker compose up --build -d
docker compose ps
```

Open:

- Frontend: <http://localhost:3000>
- Backend health: <http://localhost:8011/health>
- API docs: <http://localhost:8011/docs>

Useful commands:

```powershell
docker compose logs -f backend
docker compose logs -f frontend
docker compose down
```

The app uses a local SQLite file under `database/` by default. The backend container runs `alembic upgrade head` before startup. For the non-Docker path, run `alembic upgrade head` from the project root before launching Uvicorn, especially when upgrading an existing database. Do not delete this folder if you want to keep local progress.

### 3. Start without Docker

Terminal 1, from project root:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend\requirements.txt
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8011
```

Terminal 2:

```powershell
cd frontend
npm ci
npm run dev -- --host 127.0.0.1 --port 3000
```

### 4. Try the local MVP

1. Keep `APP_MODE=simulation`.
2. Open the Command Center and select **Quest builder**.
3. Create and activate a quest with a small target (for example, 3).
4. Open **Live control room** and use the viewer simulator or demo event buttons.
5. Try a chat burst or streamer marker to create a candidate.
6. Open **ClipSynth studio** and approve/reject the candidate.
7. Open **Community memory** to see recorded milestones and approved highlights.
8. Open **OBS overlay** to preview the browser source.

All demo activity is marked and stored in a separate `demo` workspace. It is not stored as Twitch activity.

## Switching to Twitch LIVE mode

1. Create/select a Twitch Developer application.
2. Set the exact OAuth Redirect URL to `http://localhost:8011/auth/callback`.
3. In `.env`, set `APP_MODE=live`, `TWITCH_CLIENT_ID`, `TWITCH_CLIENT_SECRET`, and a stable generated `TOKEN_ENCRYPTION_KEY`.
4. Keep `TWITCH_REDIRECT_URI=http://localhost:8011/auth/callback` exactly aligned with the Twitch console.
5. Set `VITE_API_URL=http://localhost:8011` and recreate/rebuild the services.
6. Open `http://localhost:8011/auth/login` in the browser and authorize.
7. Verify `/api/integration/status`: `connected` must be true, granted scopes must be reported, and EventSub must reach a connected/receiving state.
8. In StreamMind Studio, review the coach disclosure, confirm that chat text may be processed by your configured AI provider, and start **Live chat coach**. It requires `user:read:chat`, EventSub WebSocket transport, and all three `AI_*` settings. Use **Speak review** or opt in to spoken rolling tips; speech is generated locally by the browser.

`APP_MODE=live` never falls back to demo mode. If credentials are incomplete, LIVE remains visibly not ready and the API returns a configuration error. A configured Client ID/Secret alone does not mean a Twitch account is connected.

### Twitch scopes

The example scopes correspond to the implemented optional capabilities:

- `user:read:chat` — read chat through EventSub.
- `user:write:chat` — send chat messages.
- `moderator:read:followers` — follow notifications/follower data where applicable.
- `channel:read:subscriptions` — subscription notifications/data.
- `clips:edit` — legacy current-live-buffer clip endpoint.
- `channel:manage:clips` (or `editor:manage:clips`) — create timestamp-aligned clips from a matching Twitch VOD.
- `channel:manage:broadcast` — create actual Twitch stream markers from the Live Control Room.
- `moderator:read:suspicious_users` — receive Twitch suspicious-user EventSub signals.
- `moderator:manage:banned_users` — submit creator-confirmed channel bans through Twitch.

Remove scopes you do not intend to use; the related features will remain unavailable. Reauthorize after changing scopes. `moderator:manage:banned_users` is only needed if you want to execute bans from BotGuard; detection and review can run without it. Twitch's current docs should be checked again before changing event types or clip behavior.

## PostgreSQL deployment

SQLite is the default local-development option. PostgreSQL support is provided through `psycopg` and Alembic migrations.

1. Set `DATABASE_URL=postgresql+psycopg://questcast:<password>@db:5432/questcast` and real database credentials in `.env`.
2. Start PostgreSQL: `docker compose --profile postgres up -d db`.
3. Set `AUTO_CREATE_SCHEMA=false`.
4. Run the migration from the backend container or a Python environment with the project dependencies:

```powershell
docker compose run --rm backend alembic upgrade head
```

5. Start the app: `docker compose up --build -d backend frontend`.

Back up the database before migrations or upgrades. The initial baseline migration is idempotent for an existing local schema; later schema changes should be normal forward-only Alembic revisions.

## AI provider (optional)

Leave `AI_BASE_URL`, `AI_API_KEY`, and `AI_MODEL` blank for deterministic local suggestions. To use an OpenAI-compatible endpoint, configure all three in the backend `.env` and restart the backend. The API endpoint is `POST /api/workspace/ai/suggestions`. Only generated copy is returned; the domain engine remains authoritative for activity, scoring and approval.

Chat break mode can use the official OpenAI Responses API for creator-reviewed poll and meme drafts. Set `OPENAI_API_KEY` in the backend `.env`; `OPENAI_MODEL` defaults to `gpt-4o-mini`. If no key is set or the API is unavailable, QuestCast uses a curated local playlist. OpenAI API usage is billed separately from a ChatGPT subscription. The creator reviews the complete playlist and presses **Approve & start break** before any generated copy is posted.

To show animated GIPHY results, set `VITE_GIPHY_API_KEY` in the frontend `.env` or Docker build environment and rebuild the frontend. GIPHY search runs in the browser with its `g` content rating. The key is a public client key embedded in the frontend build; do not put a private server credential there. Without it, meme captions still appear on the OBS overlay.

## API overview

| Area | Endpoint | Purpose |
|---|---|---|
| Health | `GET /health` | Liveness check |
| Twitch | `GET /api/integration/status` | Honest mode, account, scopes and EventSub status |
| Workspace | `GET /api/workspace/overview` | Dashboard data |
| Quests | `GET/POST /api/workspace/quests` | List/create quests |
| Quests | `POST /api/workspace/quests/{id}/activate` | Activate one quest |
| Quests | `POST /api/workspace/quests/{id}/pause` | Pause a quest |
| Participation | `POST /api/workspace/quests/{id}/participate` | Simulation-only test participation |
| Demo | `POST /api/workspace/demo/events` | Generate labelled demo signals |
| ClipSynth | `GET /api/workspace/candidates` | Candidate queue |
| ClipSynth | `POST /api/workspace/candidates/{id}/review` | Approve/reject |
| ClipSynth | `POST /api/workspace/candidates/{id}/clip` | Attempt a real clip after approval (60s channel cooldown) |
| ClipSynth | `GET /api/workspace/candidates/{id}/clip-status` | Poll clip workflow state |
| ClipSynth | `POST /api/workspace/candidates/{id}/title-suggestion` | Draft a labelled AI title suggestion |
| ClipSynth | `POST /api/workspace/candidates/{id}/caption-suggestion` | Draft a labelled AI caption suggestion |
| StreamQuest | `POST /api/workspace/stream-marker` | Create a verified Twitch streamer marker (LIVE only) |
| BotGuard | `GET /api/workspace/bot-guard/reviews` | List suspicious-account reviews and evidence |
| BotGuard | `POST /api/workspace/bot-guard/reviews/{id}/dismiss` | Dismiss a review without enforcement |
| BotGuard | `POST /api/workspace/bot-guard/reviews/{id}/explanation` | Optional AI explanation of recorded evidence |
| BotGuard | `POST /api/workspace/bot-guard/reviews/{id}/ban` | Creator-confirmed channel ban via Twitch API |
| BotGuard | `POST /api/workspace/bot-guard/demo-signal` | Add a clearly labelled SIMULATION review signal |
| Community | `GET /api/workspace/leaderboard` | Participation totals and derived badges |
| Analytics | `GET /api/workspace/analytics` | UTC event heatmap, quest funnel and observed viewer peaks |
| Moderators | `GET/POST /api/workspace/moderators` | List/grant review-only moderator access |
| Moderators | `DELETE /api/workspace/moderators/{twitch_user_id}` | Revoke moderator grant |
| Moderators | `GET /api/workspace/moderator/workspaces` | List creator workspaces where signed-in user is a moderator |
| Memory | `GET /api/workspace/memory` | Timeline entries |
| Memory | `GET /api/workspace/recap` | Factual deterministic recap |
| Overlay | `GET /api/workspace/overlay/state` | Current overlay state |
| Overlay | `POST /api/workspace/overlay/token` | Create a private LIVE OBS token |
| AI | `POST /api/workspace/ai/suggestions` | Optional copy suggestions |

Interactive OpenAPI docs: `http://localhost:8011/docs`.

## Testing

```powershell
pip install -r backend\requirements-dev.txt
pytest -q
```

Frontend static type check and production build:

```powershell
cd frontend
npx tsc --noEmit
npm run build
```

Real Twitch tests are opt-in and require authorized credentials/network access:

```powershell
$env:RUN_TWITCH_INTEGRATION="1"
pytest -m twitch_live -v
```

Offline tests do not prove Twitch OAuth, EventSub delivery, or clip creation. Those are only verified by a real authorized Twitch session.

## Security notes

- Never commit `.env`, tokens, database files or overlay tokens.
- Rotate a Twitch Client Secret if it has been exposed in a shared archive or repository.
- Use HTTPS and `COOKIE_SECURE=true` outside localhost.
- Keep `TOKEN_ENCRYPTION_KEY` stable and backed up securely; changing it makes existing encrypted tokens unreadable.
- Treat a LIVE OBS URL containing its private token as a secret.
- Do not expose the backend directly to the public internet without deployment hardening, TLS, backups, rate limits and monitoring.

See [ARCHITECTURE.md](ARCHITECTURE.md), [ROADMAP.md](ROADMAP.md), [SECURITY.md](SECURITY.md), [API_INTEGRATIONS.md](API_INTEGRATIONS.md), and [TESTING.md](TESTING.md).


## Engagement phase additions

- **Last-60s hype:** `SlidingWindow` receives each verified workspace event once; its active window is exposed through `/api/workspace/overview` and `/api/workspace/overlay/state`. The score is a transparent weighted event score, displayed as a capped 0–100 meter. The in-process window restores its recent events from the database after restart. Keep one API worker unless a shared streaming store (e.g. Redis) is configured.
- **Chat commands:** `!join`, `!quest`, `!progress`, and `!leaderboard`. A 5-second per-user/per-command cooldown is persisted. Moderators can use `!quest start` and `!quest pause`; the handler checks Twitch moderator/broadcaster badges. Bot replies require the authenticated creator's `user:write:chat` scope.
- **Chat break:** from **Chat break**, prepare a 6–18 minute playlist, review the generated/curated polls and meme captions, then start it. LIVE mode requires the `user:read:chat` and `user:write:chat` scopes. Chat votes are accepted only from verified EventSub messages; the `!vote` cooldown is persisted and vote records store a per-poll hash rather than Twitch user IDs or raw messages. The backend scheduler continues rotating activities while QuestCast stays running.
- **Leaderboard:** `/api/workspace/leaderboard` aggregates unique viewer participation. `Quest finisher` and `Community regular` badges are derived from persisted quest completions and participation counts.
- **Clip workflow:** a channel-wide 60-second cooldown, persisted `clip_status`, `/candidates/{id}/clip-status` polling, and AI title suggestions marked as suggestions. Twitch clip URLs remain blank until Get Clips confirms the created clip.
- **OBS:** transparent canvas, `violet`/`cyan`/`amber` themes, recent milestone/raid alert queue, one-time token rotation (new token revokes previous tokens), and a backend-unreachable last-known-state indicator.
- **Moderators:** creators can grant/revoke review-only access by Twitch user ID. A moderator signs in with their own Twitch account; the app discovers granted creator workspaces and lets them select one. Candidate list/review requests include `?workspace=twitch:<creator-db-user-id>`; the grant is checked server-side. Moderators cannot create clips or change creator settings.
- **Analytics:** `/api/workspace/analytics` returns UTC hour-of-day activity, per-quest funnel, and peak viewer counts from recorded Helix viewer samples. A background sampler records Helix `/streams` `viewer_count` once per minute while live, for either WebSocket or webhook transport. If no samples exist for a quest, peak viewers are reported as unavailable—not estimated.

### New API routes

`GET /leaderboard`, `GET /analytics`, `GET /moderators`, `POST /moderators`, `DELETE /moderators/{twitch_user_id}`, `GET /moderator/workspaces`, `POST /candidates/{id}/title-suggestion`, and `GET /candidates/{id}/clip-status`.

Apply deployment schema changes with `alembic upgrade head`.


## BotGuard moderation model

BotGuard is an AI-assisted review workflow, not an autonomous ban bot. It combines Twitch's `channel.suspicious_user.message` / `channel.suspicious_user.update` notifications with local rolling chat signals (burst volume and repeated-message hashes). Raw chat message text is not retained in persisted Twitch or workspace event payloads; only a normalized hash, length and chatter identifiers are stored for the rolling signal check.

Risk scores and evidence labels are deterministic and explainable. Optional AI only summarizes the evidence already recorded. It cannot label an account conclusively, alter the score, dismiss a review or take moderation action. The creator must explicitly confirm each channel ban. Twitch's `POST /helix/moderation/bans` is called only with a creator session and the `moderator:manage:banned_users` scope; Twitch remains authoritative about whether the user has moderation authority and whether the ban succeeded. This is a channel chat ban, not a platform-wide account suspension.

Live creator-marked moments use Twitch `POST /helix/streams/markers` and are persisted as timestamped `stream.marker` events. The marker feature requires `channel:manage:broadcast`; Twitch rejects marker creation when the stream is offline or VODs are disabled.

Twitch VOD clipping uses `POST /helix/videos/clips` with the matching archive VOD ID and `vod_offset`, then polls `GET /helix/clips?id=...`. If the matching VOD is not available or the timestamp is outside its range, the candidate remains in the queue and no clip URL is fabricated. The VOD workflow requires `channel:manage:clips` or `editor:manage:clips`.

## Expansion systems (v0.4 foundation)

The Expansion Lab adds a non-cash viewer economy, inventory and item trading, branching story votes, a Twitch Extension panel starter, and guarded job contracts for vision analysis, social publishing and game adapters.

- **Quest economy:** Quest Coins have no cash value. The starter catalogue includes Spotlight, Confetti Burst and Quest Reroll. Purchases update a ledger and inventory; trades transfer items only after acceptance. The `reroll` ability creates a creator-review request rather than silently changing a live story.
- **Branching stories:** viewers vote once per chapter (they may change their vote while it is open). The creator locks the winning branch. A child chapter must reference the locked parent node and the selected parent choice. Ties require an explicit creator decision; no random tie-break is used.
- **Twitch Extension:** `frontend/extension/` contains a panel starter using Twitch's Extension Helper. The backend verifies Twitch-signed HS256 JWTs with the base64 shared secret. Configure `TWITCH_EXTENSION_SECRET_B64` and `TWITCH_EXTENSION_ORIGIN`, register the extension in the Twitch Developer Console, set the public HTTPS API host in `frontend/extension/extension.js`, then upload/test the extension. This source package is not itself a Twitch-approved or released extension.
- **Full-stream vision:** the API records an opt-in analysis request but returns `blocked_unconfigured` until an FFmpeg frame-sampling worker and multimodal vision provider are installed. It does not fetch or analyse video in this build.
- **Social publishing:** only a creator-approved candidate with a verified clip URL can enter the publishing queue. Jobs remain `awaiting_platform_oauth` until a platform OAuth integration and publishing worker are configured. A queued job is not a published post.
- **Gameplay:** the Expansion Lab includes a playable browser-only Quest Run mini-game, keyboard/touch movement, a suggestion-only AI coach, and creator-triggered actions from a fixed allowlist. Actions are recorded in sandbox mode; no game process is read or controlled. Real actions require a documented, permissioned game-specific adapter. No input injection or anti-cheat bypass is implemented.
- **3D studio visual:** Expansion Lab includes a pointer-tilted CSS camera model with layered lens depth and a virtual flash interaction. It is decorative and does not request camera permissions or capture video.
- **AI-assisted quest progress:** the assistant lists eligible recorded events and active quests, calculates proposal points through fixed server rules, and queues proposals for explicit creator approval. It does not invent evidence or directly change progress. Only verified, non-simulated Twitch EventSub events in an enabled creator allowlist can auto-advance progress.

### Expansion API

- `GET /api/workspace/expansion/summary`
- `GET /api/workspace/expansion/economy/{viewer_id}`
- `POST /api/workspace/expansion/economy/award` (SIMULATION only)
- `POST /api/workspace/expansion/economy/purchase`
- `POST /api/workspace/expansion/economy/trades` and `POST /api/workspace/expansion/economy/trades/{id}/accept`
- `POST /api/workspace/expansion/economy/use`
- Twitch Extension wallet/shop/ability/trade endpoints under `/api/workspace/expansion/extension/` (verified Twitch Extension JWT required)
- `POST /api/workspace/expansion/story/nodes`, `GET /api/workspace/expansion/story`, vote and lock routes
- `GET /api/workspace/expansion/extension/state` and `POST /api/workspace/expansion/extension/story/{id}/vote` (Twitch Extension JWT required)
- `POST /api/workspace/expansion/vision/jobs`
- `POST /api/workspace/expansion/publish`
- `POST /api/workspace/expansion/gameplay/propose`
- `GET /api/workspace/expansion/assistant-state` (active quests, eligible evidence and pending review queue)
- `POST /api/workspace/expansion/ai-progress/policy`, `/propose` and `/{id}/approve`

Apply database migrations with `alembic upgrade head`. Migration `0005_expansion_systems` adds the expansion tables and branching parent references.
