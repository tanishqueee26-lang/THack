# Verification record

| Check | Result | Notes |
|---|---|---|
| Backend pytest | 104 passed, 2 skipped | Local automated tests; does not prove Twitch network integration |
| Python compileall | Passed | Backend modules compile |
| Fresh Alembic migration | Passed | Reached `0004_clip_caption_suggestions`; checked BotGuard table and caption column |
| TS/TSX syntax transpile | Passed | Source syntax only; no full type check |
| Full TypeScript type-check | Not completed | React dependencies/type declarations are absent from this workspace |
| Vite production build | Not completed | Frontend dependencies are absent |
| Docker build | Not completed | Must be run on the user's Windows/Docker environment |
| Twitch live integration | Not verified | Requires user-authorized Twitch credentials and a controlled test channel |
| OBS Browser Source | Not verified | Requires OBS on the user's machine |

No test result in this document is evidence that a live Twitch API call succeeded.

## Latest local run — 2026-11-02

| Check | Result | Notes |
|---|---|---|
| Backend pytest | 117 passed, 2 skipped | Set `APP_MODE=auto` to prevent a local `.env` from forcing simulation during the LIVE-boundary test. |
| Python compileall | Passed | `backend`, `migrations`, and `scripts`. |
| Frontend type-check | Passed | `npx tsc --noEmit`. |
| Frontend production build | Passed | Vite 6.4.5. |
| npm audit | Passed | 0 vulnerabilities after React Router and Vite updates. |
| Bandit | Passed | No medium/high findings in backend runtime code. |
| Docker Compose config | Passed | Validated with `.env.example` copied locally to satisfy the service `env_file`. |
| Docker image build | Not run | Docker daemon unavailable in this environment. |
| pip-audit | User-confirmed verified | Independent local rerun was blocked because this sandbox could not resolve `api.osv.dev`. |
| Twitch LIVE / OBS | Not verified | Requires an authorized Twitch account and local OBS. |

The earlier verification rows record previous environment runs and are superseded by the dated results above.

## Chat break feature — 2026-11-02

| Check | Result | Notes |
|---|---|---|
| Backend pytest | 119 passed, 2 skipped | Includes chat-break fallback and poll vote/cooldown coverage. |
| Python compileall | Passed | `backend`, `migrations`, and `scripts`. |
| Fresh Alembic upgrade | Passed | SQLite upgrade through `0006_chat_break_interactions`. |
| Frontend TypeScript check | Passed | `npx tsc --noEmit`. |
| Frontend production build | Passed | Vite 6.4.5. |
| Live OpenAI / GIPHY | Not exercised | Requires API keys and network-enabled browser/API access. |
| Twitch chat / OBS | Not verified | Requires an authorized connected Twitch channel and local OBS. |

## Interactive gameplay assistant — 2026-11-02

| Check | Result | Notes |
|---|---|---|
| Frontend TypeScript check | Passed | `npx tsc --noEmit`. |
| Frontend production build | Passed | Vite 6.4.5. |
| Python compileall | Passed | `backend`, `migrations`, and `scripts`. |
| Backend TestClient regression | Blocked | Windows TestClient could not create its socket pair (`WinError 10013`); the new assistant-state route test is present but could not execute here. |
| Real game adapter | Not run | Quest Run and allowlisted gameplay actions are browser/backend sandbox simulation only. |
