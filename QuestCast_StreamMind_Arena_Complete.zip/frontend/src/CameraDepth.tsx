import { PointerEvent, useState } from 'react';
import { Aperture, Camera, RefreshCw, Sparkles } from './icons';
import './CameraDepth.css';

export function CameraDepth() {
  const [shots, setShots] = useState(0);
  const [flash, setFlash] = useState(false);
  const [tilt, setTilt] = useState({ x: -4, y: 8 });
  const move = (event: PointerEvent<HTMLDivElement>) => {
    const box = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - box.left) / box.width - .5;
    const y = (event.clientY - box.top) / box.height - .5;
    setTilt({ x: Math.max(-13, Math.min(13, y * -22)), y: Math.max(-16, Math.min(16, x * 30)) });
  };
  const capture = () => {
    setShots(count => count + 1); setFlash(true);
    window.setTimeout(() => setFlash(false), 580);
  };
  return <section className={`camera-depth ${flash ? 'camera-flash' : ''}`} onPointerMove={move} onPointerLeave={() => setTilt({ x: -4, y: 8 })}>
    <div className="camera-copy"><span className="eyebrow"><Aperture size={12}/> DEPTH STAGE / INTERACTIVE PREVIEW</span><h2>Give your stream a <em>new perspective.</em></h2><p>A tiny 3D moment for your creator studio. Move your pointer to tilt it, then trigger a virtual capture.</p><div className="camera-actions"><button className="btn btn-primary" onClick={capture}><Camera size={14}/> Capture preview</button><span><Sparkles size={13}/>{shots ? `${shots} virtual capture${shots === 1 ? '' : 's'}` : 'No camera access · just a visual demo'}</span></div></div>
    <div className="camera-stage" aria-label="Interactive decorative 3D camera preview"><div className="camera-stage-glow"/><div className="camera-shadow"/><div className="camera-model" style={{ '--cam-rx': `${tilt.x}deg`, '--cam-ry': `${tilt.y}deg` } as React.CSSProperties}>
      <div className="camera-back"/><div className="camera-shell"><div className="camera-top"><span className="camera-dial"><i/><i/><i/><i/></span><span className="camera-hotshoe"/><span className="camera-button"/></div><div className="camera-front"><span className="camera-brand">QUESTCAST <i>Q</i></span><span className="camera-flash-window"/><span className="camera-viewfinder"><i/></span><span className="camera-lamp"/><span className="camera-lens-mount"/><span className="camera-lens"><i className="lens-ring ring-one"/><i className="lens-ring ring-two"/><i className="lens-ring ring-three"/><i className="lens-glass"><b/></i><i className="lens-glint"/></span><span className="camera-grip"/></div><div className="camera-side"/></div>
    </div><div className="camera-floor-grid"/><div className="camera-flare"/></div>
    <button className="camera-reset" aria-label="Reset camera angle" onClick={() => setTilt({ x: -4, y: 8 })}><RefreshCw size={13}/> Reset view</button>
  </section>;
}
