import { useCallback, useEffect, useState } from 'react';
import * as twitch from './twitch';

export function useIntegrationStatus() {
  const [status, setStatus] = useState<twitch.Status | null>(null);
  const [error, setError] = useState('');
  const refresh = useCallback(() => twitch.fetchStatus().then((s) => { setStatus(s); setError(''); })
    .catch((e) => { setStatus(null); setError(e.message); }), []);
  useEffect(() => { refresh(); const t = setInterval(refresh, 5000); return () => clearInterval(t); }, [refresh]);
  return { status, error, refresh };
}

export function SimBanner({ status }: { status: twitch.Status | null }) {
  if (status?.mode !== 'simulation') return null;
  return (
    <div className="border-y border-amber-400/50 bg-amber-400/15 px-4 py-2 text-center text-sm font-bold tracking-wide text-amber-200">
      ⚠ SIMULATION MODE – Twitch credentials not configured ({status.simulation_reasons.join(', ')}). Nothing on this page is real Twitch data.
    </div>
  );
}

const tone = (s: string) =>
  ['connected', 'enabled', 'subscribed', 'receiving', 'webhook-active'].includes(s) ? 'bg-emerald-400' :
  ['connecting', 'reconnecting', 'webhook-idle'].includes(s) ? 'bg-amber-400' : 'bg-red-400';
const Dot = ({ s }: { s: string }) => <span className={`mr-2 inline-block h-2.5 w-2.5 rounded-full ${tone(s)}`} />;
const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="glass p-4"><div className="mb-2 text-xs uppercase tracking-widest text-white/40">{title}</div>{children}</div>
);
const ago = (t?: string | null) => (t ? new Date(t).toLocaleTimeString() : 'never');

export function IntegrationPanel({ status, error, refresh }: { status: twitch.Status | null; error: string; refresh: () => void }) {
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [chat, setChat] = useState('');
  const run = async (fn: () => Promise<unknown>, ok?: (r: any) => string) => {
    setBusy(true); setMsg('');
    try { const r = await fn(); if (ok) setMsg(ok(r)); } catch (e: any) { setMsg(`Error: ${e.message}`); }
    setBusy(false); refresh();
  };
  if (!status) return <Card title="Twitch integration"><span className="text-red-300">Backend unreachable{error && `: ${error}`}. Status unknown.</span></Card>;
  const sim = status.mode === 'simulation';
  const canClip = status.connected && status.permissions.granted.includes('clips:edit');

  return (
    <section className="glass space-y-4 p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-xl font-bold">Twitch integration</h2>
        <span className={`rounded-full px-3 py-1 text-xs font-bold ${sim ? 'bg-amber-400/20 text-amber-200' : 'bg-emerald-400/20 text-emerald-200'}`}>
          {sim ? 'SIMULATION MODE' : 'LIVE MODE'}
        </span>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card title="Connection">
          <div><Dot s={status.connected ? 'connected' : 'x'} />{status.connected ? 'Connected' : 'Disconnected'}</div>
          <div className="mt-1 text-sm text-white/60">
            {status.account ? `Account: ${status.account.display_name} (@${status.account.login})` : 'No authenticated account'}
          </div>
          {status.token.valid === false && <div className="mt-1 text-sm text-red-300">Token invalid – reconnect Twitch.</div>}
          <div className="mt-1 text-xs text-white/40">Token last validated: {status.token.checked_at ? ago(status.token.checked_at) : 'never'}</div>
        </Card>
        <Card title="Granted permissions">
          <div className="flex flex-wrap gap-1.5 text-xs">
            {status.permissions.granted.map((s) => <span key={s} className="rounded bg-emerald-400/15 px-2 py-0.5 text-emerald-200">✓ {s}</span>)}
            {status.permissions.missing.map((m) => <span key={m.scope} title={m.feature} className="rounded bg-red-400/15 px-2 py-0.5 text-red-200">✗ {m.scope}</span>)}
          </div>
        </Card>
        <Card title="EventSub WebSocket">
          <div><Dot s={status.eventsub.status} />{status.eventsub.status}</div>
          <div className="mt-1 text-xs text-white/40">Last message: {ago(status.eventsub.last_message_at)} · reconnects: {status.eventsub.reconnects ?? 0}</div>
          <ul className="mt-2 space-y-0.5 text-xs text-white/60">
            {status.eventsub.subscriptions.map((s) => (
              <li key={s.type}><Dot s={s.status} />{s.type}: {s.status}{s.detail && ` (${s.detail})`}</li>
            ))}
          </ul>
        </Card>
        <Card title="Chat (EventSub channel.chat.message)">
          <div><Dot s={status.chat.status} />{status.chat.status}</div>
          <div className="mt-1 text-xs text-white/40">Messages seen: {status.chat.messages_seen ?? 0} · last: {ago(status.chat.last_message_at)}</div>
          {status.chat.detail && <div className="mt-1 text-xs text-red-300">{status.chat.detail}</div>}
        </Card>
        <Card title="Last received event">
          {status.last_event ? (
            <>
              <span className={`mr-2 rounded px-1.5 py-0.5 text-[10px] font-bold ${status.last_event.simulated ? 'bg-amber-400 text-black' : 'bg-twitch text-white'}`}>
                {status.last_event.simulated ? 'SIMULATED' : 'TWITCH'}
              </span>
              {status.last_event.summary}
              <div className="mt-1 text-xs text-white/40">{status.last_event.type} · {ago(status.last_event.at)}</div>
            </>
          ) : <span className="text-white/50">No events received yet.</span>}
        </Card>
        <Card title="Health history">
          {status.history.length === 0 ? <span className="text-white/50">No transitions recorded yet.</span> : (
            <ul className="max-h-32 space-y-1 overflow-auto text-xs text-white/60">
              {status.history.map((h, i) => <li key={i}>{new Date(h.at).toLocaleTimeString()} · {h.kind}: {h.status}{h.detail && ` (${h.detail.slice(0, 60)})`}</li>)}
            </ul>
          )}
        </Card>
        <Card title="API errors">
          {status.errors.length === 0 ? <span className="text-white/50">None recorded.</span> : (
            <ul className="max-h-32 space-y-1 overflow-auto text-xs text-red-200">
              {status.errors.map((e, i) => <li key={i}>{ago(e.at)} · {e.source}: {e.message}</li>)}
            </ul>
          )}
        </Card>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        {!sim && status.connected && (
          <>
            <button disabled={busy || !canClip} onClick={() => run(twitch.createClip, (r) =>
              r.status === 'verified' ? `Clip verified: ${r.url}` : `Clip NOT verified. ${r.detail}`)}
              className="rounded-full bg-twitch px-4 py-2 text-sm font-medium disabled:opacity-40">
              {busy ? 'Working…' : 'Create clip (live stream only)'}
            </button>
            <button disabled={busy} onClick={() => run(twitch.reconnectEventSub, () => 'Restarting EventSub…')}
              className="rounded-full border border-white/20 px-4 py-2 text-sm">Reconnect EventSub</button>
          </>
        )}
        {!sim && status.connected && status.permissions.granted.includes('user:write:chat') && (
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (chat.trim()) run(() => twitch.sendChat(chat), (r) =>
            r.sent ? 'Sent to your chat.' : `Twitch dropped it: ${JSON.stringify(r.drop_reason)}`).then(() => setChat('')); }}>
            <input value={chat} maxLength={500} onChange={(e) => setChat(e.target.value)} placeholder="Send a message to your chat"
              className="w-64 rounded-full border border-white/20 bg-transparent px-4 py-2 text-sm outline-none" />
            <button disabled={busy} className="rounded-full bg-twitch px-4 py-2 text-sm disabled:opacity-40">Send</button>
          </form>
        )}
        {sim && ['channel.follow', 'channel.raid', 'stream.online', 'channel.chat.message'].map((t) => (
          <button key={t} onClick={() => run(() => twitch.simulateEvent(t))}
            className="rounded-full border border-amber-400/50 px-3 py-1.5 text-xs text-amber-200">
            Simulate {t}
          </button>
        ))}
        {sim && <span className="text-xs text-amber-200/80">Simulated events are in-memory only and never stored as Twitch events. Clip creation is unavailable in simulation.</span>}
        {msg && <span className="text-sm text-white/70">{msg}</span>}
      </div>
    </section>
  );
}
