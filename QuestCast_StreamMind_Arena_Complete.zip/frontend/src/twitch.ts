// Talks to the QuestCast backend. Twitch OAuth runs server-side (authorization-code flow);
// the browser only holds an httpOnly session cookie.
const API: string = import.meta.env.VITE_API_URL ?? 'http://localhost:8011';

export interface TwitchUser { id: string; login: string; display_name: string; profile_image_url: string }
export interface Dashboard {
  live: boolean | null; viewers: number | null; followers: number | null; subscribers: number | null;
  clips: { title: string; url: string; duration: number; view_count: number }[];
  activity: { d: string; v: number }[];
  quests: { id: string; name: string; desc: string; icon: string; target: number; count: number; completed: boolean; pct: number }[];
  highlights: { start: string; end: string; score: number; reasons: Record<string, number>; summary: string; clippable: boolean }[];
}

const call = (path: string, init?: RequestInit) => fetch(API + path, { credentials: 'include', ...init });

export const login = () => { window.location.href = `${API}/auth/login`; };

export async function fetchMe(): Promise<TwitchUser | null> {
  const r = await call('/api/me');
  if (r.status === 401) return null;
  if (!r.ok) throw new Error('Backend unavailable');
  return r.json();
}

export async function fetchDashboard(): Promise<Dashboard> {
  const r = await call('/api/dashboard');
  if (!r.ok) throw new Error('Could not load dashboard');
  return r.json();
}

export const logout = () => call('/auth/logout', { method: 'POST' });

export interface Status {
  mode: 'live' | 'simulation'; simulation_reasons: string[]; redirect_uri: string;
  connected: boolean; account: TwitchUser | null;
  permissions: { granted: string[]; missing: { scope: string; feature: string }[] };
  token: { valid: boolean | null; checked_at: string | null };
  eventsub: { status: string; session_id?: string | null; connected_at?: string | null; last_message_at?: string | null;
              reconnects?: number; subscriptions: { type: string; status: string; detail?: string }[] };
  chat: { status: string; detail?: string; last_message_at?: string | null; messages_seen?: number };
  last_event: { type: string; summary: string; at: string; simulated: boolean } | null;
  errors: { at: string; source: string; message: string }[];
  history: { at: string; kind: string; status: string; detail: string }[];
}
export type ClipResult = { status: 'verified' | 'unverified'; id: string; edit_url: string; url?: string; detail?: string };

export async function fetchStatus(): Promise<Status> {
  const r = await call('/api/integration/status');
  if (!r.ok) throw new Error(`Backend returned ${r.status}`);
  return r.json();
}
const post = async (path: string, body?: unknown) => {
  const r = await call(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.detail ?? `Request failed (${r.status})`);
  return j;
};
export const createClip = (): Promise<ClipResult> => post('/api/clips');
export const simulateEvent = (type: string) => post('/api/simulate/event', { type });
export const reconnectEventSub = () => post('/api/integration/reconnect');
export const sendChat = (message: string): Promise<{ sent: boolean; message_id: string | null; drop_reason: unknown }> => post('/api/chat/send', { message });
