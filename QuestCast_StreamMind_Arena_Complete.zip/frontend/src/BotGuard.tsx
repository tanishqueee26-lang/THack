import { useState } from 'react';
import { BotReview } from './workspace';
import { AlertTriangle, Check, RefreshCw, ShieldCheck, Sparkles, X } from './icons';

export function BotGuardPage({ reviews, mode, role, canBan, workspace, onRefresh, onDismiss, onBan, onDemo, onExplain }: {
  reviews: BotReview[]; mode: string; role: 'creator' | 'moderator'; canBan: boolean; workspace?: string;
  onRefresh: () => void; onDismiss: (id: string) => Promise<void>; onBan: (id: string) => Promise<void>;
  onDemo: () => Promise<void>; onExplain: (id: string) => Promise<{ suggestion: string; generated_by: string; warning: string }>;
}) {
  const [busy, setBusy] = useState('');
  const [explanations, setExplanations] = useState<Record<string, string>>({});
  const [error, setError] = useState('');
  const run = async (id: string, fn: () => Promise<void>, success?: string) => {
    setBusy(id); setError('');
    try { await fn(); if (success) setError(success); } catch (e) { setError(e instanceof Error ? e.message : 'Action failed'); }
    finally { setBusy(''); }
  };
  const pending = reviews.filter(x => x.status === 'pending');
  return <>
    <div className="page-heading"><div><div className="eyebrow">TRUST & SAFETY / BOTGUARD</div><h1>Protect the community signal.</h1><p>Surface suspicious chat patterns and Twitch trust signals. Every enforcement action remains under creator control.</p></div><div className="botguard-actions"><button className="btn btn-quiet" onClick={onRefresh}><RefreshCw size={14}/> Refresh</button>{mode === 'simulation' && <button className="btn btn-primary" disabled={!!busy} onClick={() => run('demo', onDemo)}>Generate demo signal</button>}</div></div>
    <div className="botguard-notice"><ShieldCheck size={17}/><span><b>Human-reviewed moderation</b><small>Risk scores are triage signals, not proof that someone is a bot. QuestCast never bans automatically. AI explanations cannot change scores or trigger actions.</small></span></div>
    <div className="metric-grid botguard-metrics"><div className="metric-card"><div className="metric-top"><span className="metric-icon"><AlertTriangle size={17}/></span><span className="metric-hint">Needs review</span></div><strong>{pending.length}</strong><span className="metric-label">Pending accounts</span></div><div className="metric-card"><div className="metric-top"><span className="metric-icon"><ShieldCheck size={17}/></span><span className="metric-hint">Queue</span></div><strong>{reviews.filter(x => x.status === 'banned').length}</strong><span className="metric-label">Twitch-confirmed bans</span></div><div className="metric-card"><div className="metric-top"><span className="metric-icon"><Check size={17}/></span><span className="metric-hint">Reviewed</span></div><strong>{reviews.filter(x => x.status === 'dismissed').length}</strong><span className="metric-label">Dismissed reviews</span></div></div>
    {error && <div className="botguard-error" role="status">{error}</div>}
    <section className="panel botguard-panel"><div className="panel-heading"><div><span className="eyebrow">ACCOUNT REVIEW QUEUE</span><h3>Suspicious activity</h3></div><span className="count-chip">{reviews.length} records</span></div>
      {!reviews.length ? <div className="empty-state"><span className="empty-icon"><ShieldCheck size={22}/></span><b>No suspicious accounts detected</b><p>When chat bursts, repeated message patterns or Twitch's own suspicious-user notifications meet the review threshold, accounts will appear here.</p>{mode === 'simulation' && <button className="btn btn-primary" onClick={() => run('demo', onDemo)}>Create a sample review</button>}</div> : <div className="bot-review-list">{reviews.map(item => <article className="bot-review-card" key={item.id}>
        <div className="bot-review-head"><div><span className="eyebrow">{item.simulated ? 'SIMULATION SIGNAL' : item.official_suspicious_status ? 'TWITCH TRUST SIGNAL' : 'QUESTCAST CHAT HEURISTIC'}</span><h4>{item.display_name} <small>@{item.login || 'unknown'}</small></h4><p>User ID · {item.twitch_user_id}</p></div><div className={`bot-risk ${item.risk_score >= 70 ? 'high' : 'medium'}`}><strong>{item.risk_score}</strong><small>risk / 100</small></div></div>
        <div className="bot-review-meta"><span>Heuristic signal indicator · {Math.round(item.confidence * 100)}%</span><span>Last seen · {new Date(item.last_seen_at).toLocaleString()}</span><span className={`review-status ${item.status}`}>{item.status}</span></div>
        <div className="bot-evidence">{item.evidence.map(ev => <div key={ev.code}><AlertTriangle size={13}/><span>{ev.label}</span>{ev.weight > 0 && <b>+{ev.weight}</b>}</div>)}</div>
        {explanations[item.id] && <div className="ai-suggestion"><span>AI EXPLANATION · NOT A MODERATION DECISION</span><p>{explanations[item.id]}</p></div>}
        <div className="bot-review-actions">{item.status === 'pending' && <button className="btn btn-quiet" disabled={!!busy} onClick={() => run(item.id, () => onDismiss(item.id))}><X size={14}/> Mark safe / dismiss</button>}{item.status === 'pending' && role === 'creator' && mode === 'live' && <button className="btn btn-danger" disabled={!canBan || !!busy || item.simulated} title={!canBan ? 'Reconnect Twitch with moderator:manage:banned_users' : 'Send a real Twitch ban after confirmation'} onClick={() => run(item.id, () => onBan(item.id))}><ShieldCheck size={14}/> {canBan ? 'Ban on Twitch' : 'Ban permission required'}</button>}{item.status === 'pending' && <button className="btn btn-quiet" disabled={!!busy} onClick={() => run(`ai-${item.id}`, async () => { const result = await onExplain(item.id); setExplanations(x => ({...x, [item.id]: result.suggestion})); })}><Sparkles size={14}/> Explain evidence</button>}{item.status !== 'pending' && <span className="muted-copy">{item.action_detail || 'Review completed.'}</span>}</div>
      </article>)}</div>}
    </section>
    <p className="muted-copy botguard-footnote">{workspace ? `Reviewing workspace ${workspace}. ` : ''}Twitch's suspicious-user events are first-party trust signals; local burst/repetition rules are only heuristics. Banning requires a creator-initiated action and the granted <code>moderator:manage:banned_users</code> scope.</p>
  </>;
}
