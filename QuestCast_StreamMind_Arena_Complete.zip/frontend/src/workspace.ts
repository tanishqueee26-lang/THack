const API = import.meta.env.VITE_API_URL ?? 'http://localhost:8011';
const call = async <T,>(path: string, init?: RequestInit): Promise<T> => {
  const r = await fetch(`${API}/api/workspace${path}`, { credentials: 'include', ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) } });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail ?? `Request failed (${r.status})`);
  return data as T;
};
export type Quest = { id: string; title: string; description: string; objective: string; target: number; progress: number; percent: number; status: string; stages: string[]; stage_progress?: { name: string; status: string }[]; participants: number; created_at: string; completed_at: string | null };
export type Candidate = { id: string; source: string; start_at: string; end_at: string; score: number; confidence: number; reasons: Record<string, number>; status: string; clip_id: string | null; clip_url: string | null; clip_status: string; clip_detail: string; title_suggestion: string | null; caption_suggestion: string | null; simulated: boolean };
export type Activity = { id: string; type: string; source: string; summary: string; at: string; simulated: boolean };
export type Hype = { window_seconds: number; as_of: string | null; count: number; score: number; by_type: Record<string, number>; start: string | null; end: string | null };
export type Overview = { mode: string; creator: string; role: 'creator' | 'moderator'; active_quest: Quest | null; metrics: { participations: number; pending_candidates: number; milestones: number; events: number }; candidates: Candidate[]; activity: Activity[]; hype: Hype };
export type LeaderboardEntry = { participant_id: string; display_name: string; quests_joined: number; quests_completed: number; badges: string[] };
export type Analytics = { event_heatmap_by_hour: number[]; quest_completion_funnel: { quest: string; created: number; participants: number; completed: number }[]; peak_viewers_per_quest: { quest: string; peak_viewers: number | null; measurement: string }[]; mode: string };
export type Memory = { id: string; kind: string; title: string; body: string; at: string; simulated: boolean };
export type OverlayState = { mode: string; quest: Quest | null; activity: Activity[]; milestones: { title: string; body: string; at: string }[]; hype: Hype; alerts: { id: string; summary: string; at: string }[]; chat_break?: ChatBreakState | null };
export type ChatBreakActivity = { id?: string; kind: 'poll' | 'meme'; title: string; prompt: string; options: string[]; meme_query: string; meme_caption: string; votes?: number[]; status?: string };
export type ChatBreakState = { id: string; status: 'active' | 'stopped' | 'completed'; started_at: string; ends_at: string; interval_seconds: number; current: ChatBreakActivity | null; activities: ChatBreakActivity[]; mode: 'live' | 'simulation' };
export type ChatBreakPlan = { duration_minutes: number; interval_seconds: number; theme: string };
export type ChatBreakDraft = ChatBreakPlan & { activities: ChatBreakActivity[] };
export type EngagementCoachReport = { id: string; at: string; message_count: number; topics: string[]; ideas: string[]; insight: string; generated_by: string; dropped_messages: number };
export type EngagementCoachState = { enabled: boolean; pending_messages: number; total_seen: number; last_report: EngagementCoachReport|null; error: string; started_at: string|null; mode: string; provider_configured: boolean; transport: string };
export type BotReview = { id: string; twitch_user_id: string; login: string; display_name: string; risk_score: number; confidence: number; status: 'pending' | 'dismissed' | 'banned'; evidence: { code: string; label: string; weight: number }[]; official_suspicious_status: string; first_seen_at: string; last_seen_at: string; action_at: string | null; action_by: string; action_detail: string; simulated: boolean };
export type ExpansionAssistantState = {
  quests: { id: string; title: string; progress: number; target: number }[];
  events: { id: string; event_type: string; summary: string; source: string; occurred_at: string; simulated: boolean; points: number }[];
  proposals: { id: string; quest_id: string; quest_title: string; event_id: string; event_type: string; event_summary: string; simulated: boolean; points: number; reason: string; created_at: string }[];
};
const post = <T,>(path: string, body?: unknown) => call<T>(path, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) });
export const api = {
  overview: (workspace?: string) => call<Overview>(`/overview${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  quests: (workspace?: string) => call<Quest[]>(`/quests${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  createQuest: (body: { title: string; description: string; objective: string; target: number; stages: string[] }) => post<Quest>('/quests', body),
  activate: (id: string) => post<Quest>(`/quests/${id}/activate`),
  pause: (id: string) => post<Quest>(`/quests/${id}/pause`),
  participate: (id: string, participant_id: string, display_name: string) => post<Quest>(`/quests/${id}/participate`, { participant_id, display_name }),
  demoEvent: (type: string, display_name: string, count = 1) => post<{ created: number }>('/demo/events', { type, display_name, count }),
  candidates: (workspace?: string) => call<Candidate[]>(`/candidates${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  moderatorWorkspaces: () => call<{ workspace: string; creator: string }[]>('/moderator/workspaces'),
  leaderboard: (workspace?: string) => call<LeaderboardEntry[]>(`/leaderboard${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  analytics: (workspace?: string) => call<Analytics>(`/analytics${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  titleSuggestion: (id: string) => post<{ title: string; label: string; generated_by: string; is_suggestion: boolean }>(`/candidates/${id}/title-suggestion`),
  captionSuggestion: (id: string) => post<{ caption: string; label: string; generated_by: string; is_suggestion: boolean }>(`/candidates/${id}/caption-suggestion`),
  clipStatus: (id: string) => call<{ id: string; status: string; clip_id: string | null; clip_url: string | null; detail: string }>(`/candidates/${id}/clip-status`),
  moderators: () => call<{ twitch_user_id: string; display_name: string }[]>('/moderators'),
  addModerator: (twitch_user_id: string, display_name: string) => post('/moderators', { twitch_user_id, display_name }),
  removeModerator: (id: string) => call(`/moderators/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  review: (id: string, status: 'approved' | 'rejected', workspace?: string) => post<Candidate>(`/candidates/${id}/review${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`, { status }),
  clip: (id: string) => post<{ status: string; url?: string; detail?: string; note?: string }>(`/candidates/${id}/clip`),
  memory: (workspace?: string) => call<Memory[]>(`/memory${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  recap: (workspace?: string) => call<{ summary: string; generated_by: string; event_count: number; completed_quests: string[]; next_objective: { title: string; objective: string } | null }>(`/recap${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  overlay: (token?: string) => call<OverlayState>('/overlay/state', token ? { headers: { 'X-Overlay-Token': token } } : undefined),
  chatBreak: () => call<ChatBreakState | null>('/chat-break'),
  prepareChatBreak: (plan: ChatBreakPlan) => post<{ activities: ChatBreakActivity[]; generated_by: string; warning?: string }>('/chat-break/prepare', plan),
  engagementCoach: () => call<EngagementCoachState>('/engagement-coach'),
  startEngagementCoach: () => post<EngagementCoachState>('/engagement-coach/start'),
  stopEngagementCoach: () => post<EngagementCoachState>('/engagement-coach/stop'),
  startChatBreak: (draft: ChatBreakDraft) => post<ChatBreakState>('/chat-break/start', draft),
  stopChatBreak: () => post<ChatBreakState>('/chat-break/stop'),
  revokeOverlayTokens: () => call<{ revoked: number }>('/overlay/token', { method: 'DELETE' }),
  createOverlayToken: () => post<{ token: string; warning: string }>('/overlay/token'),
  aiSuggestion: (kind: 'quest_ideas' | 'highlight_copy' | 'recap_copy', context: string) => post<{ suggestion: string; generated_by: string; is_suggestion: boolean }>('/ai/suggestions', { kind, context }),
  markStream: (description: string) => post<{ created: boolean; marker_id: string; position_seconds: number | null; created_at: string; candidate_note: string }>('/stream-marker', { description }),
  botReviews: (workspace?: string) => call<BotReview[]>(`/bot-guard/reviews${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  botDemoSignal: (display_name: string) => post<BotReview>('/bot-guard/demo-signal', { display_name }),
  botDismiss: (id: string, workspace?: string) => post<BotReview>(`/bot-guard/reviews/${id}/dismiss${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  botBan: (id: string, reason: string) => post<BotReview & { confirmed_by_twitch: boolean }>(`/bot-guard/reviews/${id}/ban`, { reason }),
  botExplanation: (id: string, workspace?: string) => post<{ suggestion: string; generated_by: string; is_suggestion: boolean; warning: string }>(`/bot-guard/reviews/${id}/explanation${workspace ? `?workspace=${encodeURIComponent(workspace)}` : ''}`),
  expansionAssistantState: () => call<ExpansionAssistantState>('/expansion/assistant-state'),
  proposeProgress: (quest_id: string, event_id: string) => post<{ proposal_id: string; points: number; status: string; evidence: { event_id: string; event_type: string; source: string; simulated: boolean }; ai_role: string }>('/expansion/ai-progress/propose', { quest_id, event_id }),
  approveProgress: (id: string) => post<{ proposal_id: string; status: string; progress: number; quest_id: string; approved_by: string }>(`/expansion/ai-progress/${id}/approve`),
  sandboxGameAction: (action: 'show_hint' | 'announce_milestone' | 'trigger_safe_event', payload: Record<string, unknown>) => post<{ job_id: string; status: string; detail: string }>('/expansion/gameplay/propose', { adapter: 'sandbox', action, payload }),
};
