import { useEffect, useState } from 'react';
import { Activity, ArrowUpRight, Check, Clock3, MessageCircle, Sparkles, X } from './icons';
import { api, ChatBreakActivity, ChatBreakDraft, ChatBreakState } from './workspace';
import './ChatBreak.css';

const giphyKey = import.meta.env.VITE_GIPHY_API_KEY as string | undefined;

export function MemeEmbed({ query, caption, compact = false }: { query: string; caption: string; compact?: boolean }) {
  const [gif, setGif] = useState<{ image: string; url: string } | null>(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    let current = true;
    setGif(null);
    if (!giphyKey || !query) return () => { current = false; };
    setLoading(true);
    const params = new URLSearchParams({ api_key: giphyKey, q: query, rating: 'g', limit: '1' });
    fetch(`https://api.giphy.com/v1/gifs/search?${params.toString()}`)
      .then(response => response.ok ? response.json() : Promise.reject(new Error('GIPHY request failed')))
      .then(data => {
        const item = data?.data?.[0];
        const image = item?.images?.fixed_height?.url ?? item?.images?.downsized_medium?.url;
        const url = item?.url;
        if (current && image && typeof url === 'string' && url.startsWith('https://giphy.com/')) setGif({ image, url });
      })
      .catch(() => { if (current) setGif(null); })
      .finally(() => { if (current) setLoading(false); });
    return () => { current = false; };
  }, [query]);

  return <div className={`break-meme ${compact ? 'compact' : ''}`}>
    {gif ? <a href={gif.url} target="_blank" rel="noreferrer" aria-label="View this GIF on GIPHY"><img src={gif.image} alt={caption} loading="lazy" /></a> :
      <div className="break-meme-placeholder"><Sparkles size={compact ? 18 : 24} /><span>{loading ? 'Finding a G-rated reaction…' : caption}</span></div>}
    <small>{gif ? 'GIF via GIPHY' : !giphyKey ? 'Add VITE_GIPHY_API_KEY to enable GIPHY GIFs' : 'GIPHY GIF unavailable; caption stays on screen'}</small>
  </div>;
}

function ActivityCard({ activity, index }: { activity: ChatBreakActivity; index?: number }) {
  return <article className="break-preview-card">
    <div className="break-preview-head"><span className="eyebrow">{activity.kind === 'poll' ? 'CHAT POLL' : 'MEME MOMENT'}{typeof index === 'number' ? ` · ${index + 1}` : ''}</span><b>{activity.title}</b></div>
    <p>{activity.kind === 'poll' ? activity.prompt : activity.meme_caption}</p>
    {activity.kind === 'poll' ? <div className="break-options">{activity.options.map((option, i) => <span key={`${i}-${option}`}><b>{String.fromCharCode(65 + i)}</b>{option}</span>)}</div> : <MemeEmbed query={activity.meme_query} caption={activity.meme_caption} compact />}
  </article>;
}

export function ChatBreak({ mode, connected }: { mode: string; connected: boolean }) {
  const [duration, setDuration] = useState(12);
  const [intervalSeconds, setIntervalSeconds] = useState(180);
  const [theme, setTheme] = useState('gaming break');
  const [draft, setDraft] = useState<ChatBreakDraft | null>(null);
  const [generatedBy, setGeneratedBy] = useState('');
  const [warning, setWarning] = useState('');
  const [state, setState] = useState<ChatBreakState | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = async () => {
    try { setState(await api.chatBreak()); setError(''); } catch (e) { setError(e instanceof Error ? e.message : 'Could not load chat break'); }
  };
  useEffect(() => { void load(); const timer = window.setInterval(() => void load(), 5000); return () => window.clearInterval(timer); }, []);

  const prepare = async () => {
    setBusy(true); setError(''); setWarning(''); setNotice(''); setDraft(null);
    try {
      const plan = { duration_minutes: duration, interval_seconds: intervalSeconds, theme };
      const result = await api.prepareChatBreak(plan);
      setDraft({ ...plan, activities: result.activities });
      setGeneratedBy(result.generated_by);
      setWarning(result.warning ?? '');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not prepare activities'); }
    finally { setBusy(false); }
  };
  const start = async () => {
    if (!draft) return;
    setBusy(true); setError('');
    try { setState(await api.startChatBreak(draft)); setDraft(null); setNotice('Break started. Approved activities will rotate automatically.'); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not start break'); }
    finally { setBusy(false); }
  };
  const stop = async () => {
    setBusy(true); setError('');
    try { setState(await api.stopChatBreak()); setNotice('Chat break stopped.'); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not stop break'); }
    finally { setBusy(false); }
  };

  const canStart = mode === 'simulation' || connected;
  return <div className="chat-break-page">
    <div className="break-intro panel"><span className="break-intro-icon"><MessageCircle size={20} /></span><div><b>Keep chat rolling while you step away</b><p>Prepare a short playlist of polls and G-rated meme moments. Review every activity, then the server rotates through the approved queue and posts prompts to Twitch chat.</p></div></div>
    {error && <div className="break-error" role="alert">{error}</div>}
    {notice && <div className="break-notice" role="status"><Check size={15} />{notice}</div>}
    {state?.status === 'active' ? <>
      <section className="panel break-live-panel">
        <div className="panel-heading"><div><span className="eyebrow">{state.mode === 'simulation' ? 'DEMO BREAK' : 'LIVE CHAT BREAK'}</span><h3>Activities are running</h3></div><button className="btn btn-danger" disabled={busy} onClick={() => void stop()}><X size={14} /> Stop break</button></div>
        <p className="muted-copy">The backend rotates through this creator-approved queue every {Math.round(state.interval_seconds / 60)} minutes. Keep QuestCast running during the break.</p>
        {state.current && <ActivityCard activity={state.current} />}
        {state.current?.kind === 'poll' && <div className="break-votes">{state.current.options.map((option, i) => {
          const votes = state.current?.votes?.[i] ?? 0;
          const total = (state.current?.votes ?? []).reduce((a, b) => a + b, 0);
          return <div className="break-vote-row" key={`${i}-${option}`}><span>{String.fromCharCode(65 + i)} · {option}</span><b>{votes}</b><i><em style={{ width: `${total ? votes / total * 100 : 0}%` }} /></i></div>;
        })}<small>Viewers vote in Twitch chat with !vote A, !vote B, or !vote C. A viewer can change their vote while this poll is active.</small></div>}
        <div className="break-queue"><b>Approved queue</b>{state.activities.map((activity, i) => <div key={activity.id ?? i} className={activity.id === state.current?.id ? 'current' : ''}><span>{i + 1}</span><span>{activity.kind === 'poll' ? <Check size={13} /> : <Sparkles size={13} />}</span><b>{activity.title}</b><small>{activity.status === 'closed' ? 'played' : activity.status === 'active' ? 'now' : 'up next'}</small></div>)}</div>
      </section>
    </> : <>
      <section className="panel break-setup-panel">
        <div className="panel-heading"><div><span className="eyebrow">BREAK SETUP</span><h3>Build a mini chat playlist</h3></div><Clock3 size={18} /></div>
        <div className="break-form">
          <label>Break length<select value={duration} onChange={e => { setDuration(Number(e.target.value)); setDraft(null); }}><option value={6}>6 minutes</option><option value={9}>9 minutes</option><option value={12}>12 minutes</option><option value={15}>15 minutes</option><option value={18}>18 minutes</option></select></label>
          <label>New activity every<select value={intervalSeconds} onChange={e => { setIntervalSeconds(Number(e.target.value)); setDraft(null); }}><option value={120}>2 minutes</option><option value={180}>3 minutes</option><option value={240}>4 minutes</option><option value={300}>5 minutes</option></select></label>
          <label>Stream theme<input value={theme} maxLength={80} onChange={e => { setTheme(e.target.value); setDraft(null); }} placeholder="cozy gaming break" /></label>
        </div>
        <div className="break-form-footer"><span>{Math.min(10, Math.ceil(duration * 60 / intervalSeconds))} activities · poll / meme mix · creator review required</span><button className="btn btn-primary" disabled={busy || !theme.trim() || !canStart} onClick={() => void prepare()}><Sparkles size={14} /> {busy ? 'Preparing…' : 'Generate preview'}</button></div>
        {!canStart && <small className="break-hint">Connect Twitch before starting a LIVE chat break.</small>}
        {warning && <div className="break-hint">{warning}</div>}
      </section>
      {draft && <section className="panel break-review-panel"><div className="panel-heading"><div><span className="eyebrow">CREATOR REVIEW · {generatedBy === 'openai_responses' ? 'OPENAI' : 'CURATED FALLBACK'}</span><h3>Review before anything is posted</h3></div><button className="btn btn-primary" disabled={busy} onClick={() => void start()}><ArrowUpRight size={14} /> Approve &amp; start break</button></div><div className="break-review-grid">{draft.activities.map((activity, index) => <ActivityCard key={index} activity={activity} index={index} />)}</div><p className="break-hint">Starting the break approves every item above. The first prompt posts immediately; the rest rotate on the selected interval.</p></section>}
      {state && <div className="break-notice"><Check size={15} />The previous break is {state.status}.</div>}
    </>}
    <section className="panel break-help"><div className="panel-heading"><div><span className="eyebrow">WHAT VIEWERS SEE</span><h3>Chat commands and OBS card</h3></div><Activity size={17} /></div><div className="break-help-grid"><div><b>Poll</b><p>Chat votes with <code>!vote A</code>, <code>!vote B</code>, or <code>!vote C</code>. Live counts appear on the transparent QuestCast overlay.</p></div><div><b>Meme moment</b><p>A G-rated animated reaction GIF appears on the overlay. Add a GIPHY client key to enable GIFs; attribution stays visible.</p></div></div><small>The OpenAI key is optional and stays on the backend. Without it, QuestCast offers curated fallback activities. OpenAI API usage is billed separately from a ChatGPT subscription.</small></section>
  </div>;
}

