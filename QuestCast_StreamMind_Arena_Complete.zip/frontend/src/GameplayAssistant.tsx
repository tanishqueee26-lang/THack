import { KeyboardEvent, useCallback, useEffect, useRef, useState } from 'react';
import { Activity, Check, Gamepad2, RefreshCw, ShieldCheck, Sparkles, Target, Zap } from './icons';
import { api, ExpansionAssistantState } from './workspace';
import './GameplayAssistant.css';

const clamp = (v: number) => Math.max(6, Math.min(94, v));
const goalSpots = [[76, 30], [25, 68], [80, 75], [47, 22], [23, 34], [67, 59]] as const;
const actions = [
  { id: 'show_hint' as const, label: 'Show a hint', copy: 'Show a gentle in-game nudge' },
  { id: 'announce_milestone' as const, label: 'Celebrate', copy: 'Stage a milestone announcement' },
  { id: 'trigger_safe_event' as const, label: 'Trigger safe event', copy: 'Play a harmless sandbox event' },
];

export function GameplayAssistant() {
  const [player, setPlayer] = useState({ x: 18, y: 50 });
  const [goal, setGoal] = useState(0);
  const [score, setScore] = useState(0);
  const [running, setRunning] = useState(true);
  const [selectedAction, setSelectedAction] = useState<(typeof actions)[number]['id']>('show_hint');
  const [ai, setAi] = useState('Collect the floating sparks. I can suggest ideas, while you choose any sandbox action to preview.');
  const [generatedBy, setGeneratedBy] = useState('local coach');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const arena = useRef<HTMLDivElement>(null);
  const goalSpot = goalSpots[goal % goalSpots.length];
  const move = useCallback((dx: number, dy: number) => {
    if (!running) return;
    const next = { x: clamp(player.x + dx), y: clamp(player.y + dy) };
    if (Math.hypot(next.x - goalSpot[0], next.y - goalSpot[1]) < 13) {
      setScore(n => n + 1); setGoal(n => n + 1);
    }
    setPlayer(next);
  }, [goalSpot, player.x, player.y, running]);
  useEffect(() => {
    const onKey = (event: globalThis.KeyboardEvent) => {
      if (!arena.current?.contains(document.activeElement) && document.activeElement !== arena.current) return;
      const key = event.key.toLowerCase();
      const delta: Record<string, [number, number]> = { arrowup: [0, -8], w: [0, -8], arrowdown: [0, 8], s: [0, 8], arrowleft: [-8, 0], a: [-8, 0], arrowright: [8, 0], d: [8, 0] };
      if (delta[key]) { event.preventDefault(); move(...delta[key]); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [move]);
  const getCoach = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const result = await api.aiSuggestion('quest_ideas', `The creator is previewing Quest Run, a browser-only sandbox mini-game. Sparks collected: ${score}. Offer one short, encouraging gameplay tip and one safe, creator-controlled interaction idea. Do not claim to control a game or invent stream events.`);
      setAi(result.suggestion); setGeneratedBy(result.generated_by);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load assistant suggestion'); }
    finally { setBusy(false); }
  };
  const previewAction = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const result = await api.sandboxGameAction(selectedAction, { score, player_x: player.x, player_y: player.y, game: 'quest_run' });
      setNotice(`${result.status.toUpperCase()} · ${result.detail}`);
    } catch (e) { setError(e instanceof Error ? e.message : 'Sandbox preview failed'); }
    finally { setBusy(false); }
  };
  const collect = (event: KeyboardEvent<HTMLDivElement>) => { if (event.key === ' ') { event.preventDefault(); move(3, 0); } };
  return <section className="panel gameplay-panel">
    <div className="panel-heading"><div><span className="eyebrow">PLAYABLE BACKGROUND · LOCAL ONLY</span><h3>Quest Run <span className="game-chip"><i /> SANDBOX</span></h3></div><div className="game-score"><Sparkles size={15}/><b>{score}</b><small>sparks</small></div></div>
    <div className="gameplay-layout">
      <div className={`game-arena ${running ? '' : 'paused'}`} ref={arena} tabIndex={0} role="application" aria-label="Quest Run mini-game. Use arrow keys or WASD to collect sparks." onKeyDown={collect}>
        <div className="arena-scanlines"/><div className="arena-orbit orbit-a"/><div className="arena-orbit orbit-b"/>
        <div className="arena-star star-a">✦</div><div className="arena-star star-b">·</div><div className="arena-star star-c">✧</div><div className="arena-star star-d">·</div>
        <div className="arena-goal" style={{ left: `${goalSpot[0]}%`, top: `${goalSpot[1]}%` }}><span>✦</span></div>
        <div className="arena-player" style={{ left: `${player.x}%`, top: `${player.y}%` }}><span>✧</span></div>
        {!running && <div className="arena-paused-label">PAUSED</div>}
        <div className="arena-hud"><span><i/> QUEST RUN / ZONE {String(Math.floor(score / 4) + 1).padStart(2, '0')}</span><b>{score.toString().padStart(2, '0')} <small>/ ∞</small></b></div>
      </div>
      <div className="game-controls">
        <div className="game-intro"><span className="expansion-icon"><Gamepad2 size={18}/></span><div><b>Collect the signal sparks</b><small>Move into the glowing target. Keyboard or tap controls both work.</small></div></div>
        <div className="game-dpad" aria-label="Movement controls"><button onClick={() => move(0, -8)} aria-label="Move up">↑</button><button onClick={() => move(-8, 0)} aria-label="Move left">←</button><button className="dpad-center" onClick={() => setRunning(v => !v)} aria-label={running ? 'Pause game' : 'Resume game'}>{running ? 'Ⅱ' : '▶'}</button><button onClick={() => move(8, 0)} aria-label="Move right">→</button><button onClick={() => move(0, 8)} aria-label="Move down">↓</button></div>
        <div className="game-control-row"><button className="btn btn-quiet" onClick={() => setRunning(v => !v)}>{running ? 'Pause' : 'Resume'}</button><button className="btn btn-quiet" onClick={() => { setPlayer({ x: 18, y: 50 }); setScore(0); setGoal(0); setRunning(true); }}>Reset run</button></div>
        <div className="game-ai-card"><div className="game-ai-label"><Sparkles size={13}/> GAMEPLAY ASSISTANT <span>{generatedBy}</span></div><p>{ai}</p><button className="btn btn-quiet" disabled={busy} onClick={() => void getCoach()}><Sparkles size={13}/> {busy ? 'Thinking…' : 'Ask for a tip'}</button></div>
        <label className="game-action-label">Creator-controlled sandbox action<select value={selectedAction} onChange={e => setSelectedAction(e.target.value as typeof selectedAction)}>{actions.map(a => <option key={a.id} value={a.id}>{a.label} · {a.copy}</option>)}</select></label>
        <button className="btn btn-primary" disabled={busy} onClick={() => void previewAction()}><Zap size={14}/> Preview safe action</button>
      </div>
    </div>
    {notice && <div className="game-result"><Check size={14}/>{notice}</div>}{error && <div className="game-error">{error}</div>}
    <div className="game-safety"><ShieldCheck size={14}/><span><b>Sandbox simulation only.</b> The mini-game runs in this browser. Assistant text is a suggestion; only your selected allowlisted action is recorded. No game process is read or controlled.</span></div>
  </section>;
}

export function ProgressAssistant() {
  const [state, setState] = useState<ExpansionAssistantState | null>(null);
  const [questId, setQuestId] = useState('');
  const [eventId, setEventId] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const refresh = useCallback(async () => {
    try {
      const data = await api.expansionAssistantState(); setState(data);
      setQuestId(current => data.quests.some(q => q.id === current) ? current : (data.quests[0]?.id ?? ''));
      setEventId(current => data.events.some(e => e.id === current) ? current : (data.events[0]?.id ?? ''));
      setError('');
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load recorded evidence'); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  const propose = async () => {
    setBusy(true); setError(''); setNotice('');
    try { const p = await api.proposeProgress(questId, eventId); setNotice(`Proposal created: ${p.points} fixed-rule point${p.points === 1 ? '' : 's'} from ${p.evidence.event_type}.`); await refresh(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not create progress proposal'); }
    finally { setBusy(false); }
  };
  const approve = async (id: string) => {
    setBusy(true); setError(''); setNotice('');
    try { const result = await api.approveProgress(id); setNotice(`Approved by creator. Quest progress is now ${result.progress}.`); await refresh(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Could not approve proposal'); }
    finally { setBusy(false); }
  };
  return <section className="panel progress-assistant-panel">
    <div className="panel-heading"><div><span className="eyebrow">RECORDED EVIDENCE → REVIEW → APPROVAL</span><h3>Quest progress assistant</h3></div><ShieldCheck size={18}/></div>
    <p className="progress-intro">The assistant can surface eligible recorded events. Server rules calculate points; a creator must approve each proposal before progress changes.</p>
    <div className="progress-propose-grid"><label>Active quest<select value={questId} onChange={e => setQuestId(e.target.value)}><option value="">Choose an active quest</option>{state?.quests.map(q => <option key={q.id} value={q.id}>{q.title} · {q.progress}/{q.target}</option>)}</select></label><label>Recorded event<select value={eventId} onChange={e => setEventId(e.target.value)}><option value="">Choose eligible evidence</option>{state?.events.map(ev => <option key={ev.id} value={ev.id}>{ev.simulated ? '[SIM] ' : ''}{ev.event_type} · +{ev.points} · {ev.summary.slice(0, 52)}</option>)}</select></label><button className="btn btn-primary" disabled={busy || !questId || !eventId} onClick={() => void propose()}><Target size={14}/> Create proposal</button></div>
    {notice && <div className="game-result"><Check size={14}/>{notice}</div>}{error && <div className="game-error">{error}</div>}
    <div className="progress-review-head"><b>Awaiting creator approval</b><button className="btn btn-quiet" disabled={busy} onClick={() => void refresh()}><RefreshCw size={13}/> Refresh</button></div>
    {state?.proposals.length ? <div className="progress-proposal-list">{state.proposals.map(p => <article className="progress-proposal" key={p.id}><div className="proposal-evidence-icon"><Activity size={15}/></div><div className="proposal-evidence-copy"><b>{p.quest_title}</b><span>{p.simulated ? 'SIMULATION · ' : ''}{p.event_type} · {p.event_summary}</span><small>{p.reason} · event {p.event_id}</small></div><strong>+{p.points}</strong><button className="btn btn-primary" disabled={busy} onClick={() => void approve(p.id)}><Check size={13}/> Approve</button></article>)}</div> : <div className="progress-empty"><Sparkles size={16}/><span><b>No proposals awaiting review</b><small>Choose an active quest and eligible recorded event to draft one.</small></span></div>}
    <div className="game-safety"><ShieldCheck size={14}/><span>No evidence is invented. Simulated events remain labelled SIMULATION. Approval is an explicit creator action.</span></div>
  </section>;
}
