import { useEffect, useRef } from 'react';

/** Interactive neon particle network drawn on a canvas behind the page. */
export default function ParticleField() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!; const ctx = c.getContext('2d')!;
    let w = 0, h = 0, raf = 0; const mouse = { x: -999, y: -999 };
    const resize = () => { w = c.width = innerWidth; h = c.height = innerHeight; };
    resize();
    const pts = Array.from({ length: 70 }, (_, i) => ({
      x: Math.random() * innerWidth, y: Math.random() * innerHeight,
      vx: (Math.random() - .5) * .5, vy: (Math.random() - .5) * .5, hue: i % 2 ? '145,70,255' : '0,245,212',
    }));
    const move = (e: MouseEvent) => { mouse.x = e.clientX; mouse.y = e.clientY; };
    addEventListener('resize', resize); addEventListener('mousemove', move);
    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of pts) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        const dm = Math.hypot(p.x - mouse.x, p.y - mouse.y);
        if (dm < 140) { p.x += (p.x - mouse.x) * .02; p.y += (p.y - mouse.y) * .02; }
        ctx.fillStyle = `rgba(${p.hue},.9)`; ctx.beginPath(); ctx.arc(p.x, p.y, 2, 0, 7); ctx.fill();
      }
      for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
        const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
        if (d < 130) { ctx.strokeStyle = `rgba(145,70,255,${(1 - d / 130) * .35})`; ctx.beginPath();
          ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke(); }
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { cancelAnimationFrame(raf); removeEventListener('resize', resize); removeEventListener('mousemove', move); };
  }, []);
  return <canvas ref={ref} className="fixed inset-0 -z-10 pointer-events-none" />;
}
