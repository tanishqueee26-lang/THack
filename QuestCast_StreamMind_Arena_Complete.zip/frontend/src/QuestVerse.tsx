import { PointerEvent, useState } from 'react';
import { Aperture, ArrowUpRight, Clapperboard, MessageCircle, Sparkles, Target, Zap } from './icons';
import { Overview, Quest } from './workspace';
import './QuestVerse.css';

type Destination = 'quests' | 'clips' | 'break' | 'memory';
const stations: { id: string; name: string; symbol: string; page: Destination; tint: string; copy: string }[] = [
  { id: 'quest', name: 'Quest core', symbol: '✧', page: 'quests', tint: 'violet', copy: 'Shape the next shared community chapter.' },
  { id: 'clips', name: 'Clip satellite', symbol: '◈', page: 'clips', tint: 'cyan', copy: 'Review the moments worth keeping.' },
  { id: 'chat', name: 'Chat moon', symbol: '✳', page: 'break', tint: 'amber', copy: 'Keep viewers playing during a break.' },
  { id: 'memory', name: 'Memory beacon', symbol: '⌘', page: 'memory', tint: 'pink', copy: 'Explore the story your community built.' },
];

export function QuestVerse({ overview, activeQuest, mode, onNavigate }: { overview: Overview | null; activeQuest: Quest | null; mode: string; onNavigate: (page: Destination) => void }) {
  const [focused, setFocused] = useState('quest');
  const [rotation, setRotation] = useState(0);
  const [paused, setPaused] = useState(false);
  const [tilt, setTilt] = useState({ x: -4, y: 9 });
  const selected = stations.find(item => item.id === focused) ?? stations[0];
  const percent = activeQuest?.percent ?? 0;
  const pointer = (event: PointerEvent<HTMLDivElement>) => {
    if (paused) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - .5;
    const y = (event.clientY - bounds.top) / bounds.height - .5;
    setTilt({ x: Math.max(-8, Math.min(8, y * -15)), y: Math.max(-13, Math.min(13, x * 22)) });
  };
  return <section className={`quest-verse ${paused ? 'verse-paused' : ''}`}>
    <div className="verse-backdrop"><i/><i/><i/><span className="verse-star star-1">✦</span><span className="verse-star star-2">·</span><span className="verse-star star-3">✧</span><span className="verse-star star-4">·</span><span className="verse-star star-5">✦</span></div>
    <div className="verse-copy"><div className="verse-kicker"><Target size={13}/> QUESTVERSE <span className={`verse-mode ${mode}`}>{mode === 'live' ? 'LIVE SIGNAL' : 'SANDBOX WORLD'}</span></div><h2>Your stream,<br/><em>in motion.</em></h2><p>Tap a satellite to explore your creator universe. Every orbit opens a real QuestCast workspace.</p>
      <div className="verse-focus"><span className={`verse-focus-icon ${selected.tint}`}>{selected.symbol}</span><div><small>SELECTED DESTINATION</small><b>{selected.name}</b><p>{selected.copy}</p></div><button aria-label={`Open ${selected.name}`} onClick={() => onNavigate(selected.page)}><ArrowUpRight size={15}/></button></div>
      <div className="verse-actions"><button className="verse-control" onClick={() => setPaused(value => !value)}>{paused ? 'Resume orbit' : 'Pause orbit'}</button><button className="verse-control" onClick={() => setRotation(value => (value + 35) % 360)}>Rotate scene <i style={{ transform: `rotate(${rotation}deg)` }}>⟳</i></button></div>
    </div>
    <div className="verse-world" onPointerMove={pointer} onPointerLeave={() => setTilt({ x: -4, y: 9 })}>
      <div className="verse-starscape"/><div className="verse-ground"/>
      <div className="verse-system" style={{ '--verse-rx': `${tilt.x}deg`, '--verse-ry': `${tilt.y + rotation}deg` } as React.CSSProperties}>
        <div className="verse-orbit orbit-wide"/><div className="verse-orbit orbit-tall"/><div className="verse-orbit orbit-flat"/>
        <div className="verse-planet planet-large"><span/></div><div className="verse-planet planet-small"><span/></div>
        <button className={`verse-node node-quest ${focused === 'quest' ? 'selected' : ''}`} onClick={() => setFocused('quest')} aria-label="Select Quest core"><span>✧</span></button>
        <button className={`verse-node node-clips ${focused === 'clips' ? 'selected' : ''}`} onClick={() => setFocused('clips')} aria-label="Select Clip satellite"><span><Clapperboard size={16}/></span></button>
        <button className={`verse-node node-chat ${focused === 'chat' ? 'selected' : ''}`} onClick={() => setFocused('chat')} aria-label="Select Chat moon"><span><MessageCircle size={15}/></span></button>
        <button className={`verse-node node-memory ${focused === 'memory' ? 'selected' : ''}`} onClick={() => setFocused('memory')} aria-label="Select Memory beacon"><span><Aperture size={16}/></span></button>
        <div className="verse-core" onClick={() => setFocused('quest')} onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setFocused('quest'); } }} role="button" tabIndex={0} aria-label="Select active quest core">
          <div className="core-aura"/><div className="core-cube"><i className="cube-face cube-front"><Sparkles size={23}/></i><i className="cube-face cube-back"/><i className="cube-face cube-left"/><i className="cube-face cube-right"/><i className="cube-face cube-top"/><i className="cube-face cube-bottom"/></div>
          <div className="core-progress"><div style={{ width: `${Math.max(5, percent)}%` }}/></div>
        </div>
      </div>
      <div className="verse-world-label"><span><i/>{mode === 'live' ? 'CHANNEL SIGNAL' : 'DEMO SIGNAL'}</span><b>{activeQuest?.title ?? 'The community nexus'}</b><small>{activeQuest ? `${activeQuest.progress} / ${activeQuest.target} quest energy` : 'Create a quest to activate the core'}</small></div>
      <div className="verse-world-metric"><Zap size={13}/><b>{overview?.hype.score.toFixed(1) ?? '0.0'}</b><small>HYPE</small></div>
      <div className="verse-ticks">{stations.map((station, i) => <button key={station.id} className={focused === station.id ? 'active' : ''} onClick={() => setFocused(station.id)} aria-label={`Focus ${station.name}`}/>)}</div>
      <button className="verse-launch" onClick={() => onNavigate(selected.page)}>Enter {selected.name}<ArrowUpRight size={13}/></button>
    </div>
  </section>;
}
