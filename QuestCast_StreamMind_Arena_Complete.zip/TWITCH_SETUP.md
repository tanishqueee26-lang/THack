# Twitch setup checklist

1. Create/select a Twitch Developer application and note its Client ID and Client Secret.
2. Select the correct app in the Developer Console.
3. Add this exact OAuth Redirect URL:

   `http://localhost:8011/auth/callback`

4. In the project root `.env`, set:
   - `APP_MODE=live`
   - `TWITCH_CLIENT_ID=...`
   - `TWITCH_CLIENT_SECRET=...`
   - `TWITCH_REDIRECT_URI=http://localhost:8011/auth/callback`
   - `TOKEN_ENCRYPTION_KEY=<generated Fernet key>`
5. Keep `EVENT_TRANSPORT=websocket` for local development.
6. Run `docker compose up --build -d`.
7. Open `http://localhost:8011/auth/login` in the browser. Do not open the callback path manually.
8. After Twitch redirects back, check `GET http://localhost:8011/api/integration/status`.

The Redirect URL is an exact match, including protocol, host, port and path. Do not register `/auth/twitch/callback`; this app implements `/auth/callback`.

## Verify real integration

A real connection requires:
- OAuth callback succeeds and creates a session;
- `/api/integration/status` shows `connected: true`;
- granted scopes are returned by Twitch token validation;
- EventSub WebSocket reports a connected session and subscriptions are enabled;
- a real event arrives and is stored with source `twitch`;
- a real chat command is processed from a verified chat notification;
- a clip is attempted only after creator approval and is stored only after Get Clips confirms it.

`mode: live` or a 307 redirect from `/auth/login` is not proof of an authenticated account or functioning EventSub session.

## Minimum scope intent

The sample `.env.example` requests the scopes needed for all currently exposed Twitch features. If you remove a scope, its feature will be unavailable and the status panel will report it missing. Reauthorize after changing scopes.

## Common failures

- `redirect_mismatch`: compare the Twitch console URL and `TWITCH_REDIRECT_URI` character-for-character. Check that the browser reaches `/auth/callback`.
- `Not Found` on callback: callback path registered in Twitch console does not match this app's route.
- OAuth error redirect: inspect `docker compose logs --tail=100 backend`; do not post secrets or authorization codes.
- Missing permissions: disconnect/reconnect and grant the newly requested scopes.
- EventSub disconnected: inspect token validity, subscription errors and backend logs.


Optional scopes for the extended workflow:

- `channel:manage:clips` — timestamp-aligned clip creation from archive VODs.
- `moderator:read:suspicious_users` — Twitch suspicious-user notifications for BotGuard.
- `moderator:manage:banned_users` — creator-confirmed channel chat bans from BotGuard.

After adding scopes to the registered OAuth request, disconnect/reconnect and verify that `/api/integration/status` lists the scopes as granted. BotGuard never bans automatically.

- `channel:manage:broadcast` — create actual Twitch stream markers from the Live Control Room.

## Optional Twitch Extension panel

1. Register a Panel Extension in the Twitch Developer Console and configure its allowed domains/origin.
2. Copy the base64 Extension Secret into `TWITCH_EXTENSION_SECRET_B64`; never put it in frontend files or commit it.
3. Set `TWITCH_EXTENSION_ORIGIN` to the exact extension origin allowed to call the QuestCast API.
4. Set `API_BASE` in `frontend/extension/extension.js` to the public HTTPS QuestCast API host.
5. Upload the files in `frontend/extension/` as the extension panel assets and test in Twitch's extension testing flow.
6. Keep the API's JWT verification enabled. The panel sends the latest token received by `Twitch.ext.onAuthorized`; the backend verifies HS256 before resolving the channel or accepting a vote.

The starter is not approved/released by Twitch. Complete the Developer Console configuration, test viewer/broadcaster roles, review requirements and publication steps before describing it as an official released extension. See the [Twitch JWT guide](https://dev.twitch.tv/docs/tutorials/extension-101-tutorial-series/jwt/) and [Extension building guide](https://dev.twitch.tv/docs/extensions/building/).
