# Last Signal: multiplayer browser arena

An original low-poly third-person battle-arena prototype. The browser client is a single `public/index.html` file. It imports Three.js 0.187.0 from jsDelivr and connects to the Node.js server over Socket.IO.

## Run locally

From PowerShell:

```powershell
cd path\to\QuestCast_StreamQuest_Expansion_Updated\multiplayer-battle-server
npm install
npm start
```

Open `http://localhost:3100`. The first player in a room is its host and can launch the match. Use the same room code on each browser; a room accepts up to 10 human players and includes 15 server-simulated AI rivals. Spectators can join a running room to watch and vote without using a player slot.

To let other devices on the same trusted LAN connect, find the host computer's LAN IP and start with:

```powershell
$env:HOST = '0.0.0.0'
npm start
```

Then open `http://HOST-LAN-IP:3100` on the other devices. The firewall must allow the chosen local port. Do not expose this prototype directly to the public internet.

## Controls

- **WASD** move; hold **Shift** to run at server-validated sprint speed; mouse moves the camera (click the arena to lock the pointer). Touch screens have a RUN toggle.
- **Space** jump; **C** toggle crouch.
- **1 / 2 / 3** select rifle, shotgun, or sniper; **R** reload; **E** pick up nearby loot.
- **Left click** fire; **right click** or **Z** toggle sniper scope zoom. Enemy shots show red tracers and impact sparks; landed hits reduce health/armor. AI rivals use a server-side 50% hit chance at 14–27m and 70% at 14m or closer.
- When you approach a free buggy, choose **YES · RIDE** or **NO · WALK**. The driver avatar appears seated in the vehicle; drive with WASD and press **T** to ride off. Forward speed is server-limited to 80 m/s (5× the previous cap), reverse to 30 m/s. Vehicles appear on the minimap and show speed in the HUD. Touch screens have a RIDE prompt and action button.
- **E** talks to a nearby island character when no loot is in reach. Mira offers a signal shard mission and story choices; collect the shards revealed by a community transmission event and return to complete it. **I** opens inventory and fixed server recipes for an armor patch or medkit.
- Room members, including spectators, can vote on scheduled supply, transmission, weather and community-mission events. Outcomes are fixed server rules; weather changes the scene, while choices spawn server-tracked resource/supply drops.

## Authority and limitations

The server owns room membership, maximum player count, player movement simulation including the fixed sprint cap, jump/crouch state, fire cooldowns, ammunition, hit checks, health/armor, loot placement and pickup distance, bot state and bot hit probability, vehicle entry/exit and bounded driving physics, and storm timing/damage. Red impact sparks are rendered client-side from server-confirmed hit events. Clients send button states and aim direction, predict their own short movement lead, then reconcile against acknowledged server state; remote entities are interpolated.

Movement uses a fixed server tick and bounded input states, with world bounds and building collision checks. Names and room codes are sanitized, room and payload sizes are capped, and fire rate/aim are validated. This is prototype anti-cheat, not a production anti-cheat system.

This demo has no account authentication, durable campaign storage (story state lasts only for the Node process), moderation, TLS configuration, Redis/multi-process room adapter, production telemetry, or integration with QuestCast points, Twitch chat, or Free Fire. Spectator votes come from browser clients; Twitch chat voting is not connected. The StreamMind AI World Director only creates creator-review text drafts in the separate workspace and cannot launch these game events. The first player to join is treated as host, so host control is only suitable for a private prototype. The game is a standalone sandbox and never controls an installed game process. It uses procedural primitive geometry and does not bundle copyrighted game assets.

The 60 FPS target depends on device/browser/GPU and has not been benchmarked across laptops. Rendering disables shadows and caps pixel ratio; the client reports its recent approximate frame rate in the document title.
