'use strict';

const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const express = require('express');
const { Server } = require('socket.io');

const PORT = Number(process.env.PORT || 3100);
const HOST = process.env.HOST || '127.0.0.1';
const TICK_MS = 50;
const MAX_PLAYERS = 10;
const BOT_COUNT = 15;
const WORLD_RADIUS = 112;
const WEAPONS = {
  rifle: { rate: 115, magazine: 30, damage: 22, range: 74, spread: 0.052, pellets: 1 },
  shotgun: { rate: 760, magazine: 8, damage: 13, range: 24, spread: 0.21, pellets: 7 },
  sniper: { rate: 1150, magazine: 5, damage: 82, range: 112, spread: 0.008, pellets: 1 },
};
const OBSTACLES = [
  { x: -46, z: -35, r: 11 }, { x: 17, z: -54, r: 12 }, { x: 51, z: -6, r: 10 },
  { x: -26, z: 23, r: 13 }, { x: 35, z: 44, r: 11 }, { x: -70, z: 9, r: 9 },
];
const VEHICLE_SPAWNS = [
  { id: 'buggy-1', x: -9, z: -71, yaw: 0.4 }, { id: 'buggy-2', x: 61, z: 27, yaw: -1.2 },
  { id: 'buggy-3', x: -54, z: 55, yaw: 2.1 }, { id: 'buggy-4', x: 12, z: 73, yaw: -0.5 },
];
const NPC_DEFS = [
  { id: 'mira', name: 'Mira · Beacon Scout', x: -5, z: 16, color: '#9c84bd' },
  { id: 'tavi', name: 'Tavi · Quartermaster', x: 19, z: 8, color: '#c39a63' },
  { id: 'sol', name: 'Sol · Weather Watch', x: -31, z: -11, color: '#6d9c9b' },
];
const EVENT_TEMPLATES = [
  { kind: 'supply', title: 'Supply Signal', prompt: 'A supply beacon is pinging. Where should the drop land?', options: [{ key: 'A', label: 'North ridge' }, { key: 'B', label: 'Old observatory' }] },
  { kind: 'transmission', title: 'Mysterious Transmission', prompt: 'A broken transmission repeats two coordinates. Which signal should the crew trace?', options: [{ key: 'A', label: 'The quiet beacon' }, { key: 'B', label: 'The storm marker' }] },
  { kind: 'weather', title: 'Weather Shift', prompt: 'The island weather is changing. Choose the next condition.', options: [{ key: 'A', label: 'Clear skies' }, { key: 'B', label: 'Signal fog' }] },
  { kind: 'mission', title: 'Community Mission', prompt: 'Choose the crew objective for this event.', options: [{ key: 'A', label: 'Recover signal shards' }, { key: 'B', label: 'Secure supply crates' }] },
];
const campaigns = new Map();
function campaignFor(code) {
  if (!campaigns.has(code)) campaigns.set(code, { eventIndex: 0, beaconUnlocked: false,
    miraBranch: null, completedMissions: 0, weatherHistory: ['clear'], lastChoice: null });
  return campaigns.get(code);
}
const app = express();
app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], maxAge: 0 }));
app.get('/health', (_req, res) => res.json({ ok: true, mode: 'prototype', rooms: rooms.size }));
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 16_384, pingInterval: 10_000, pingTimeout: 8_000 });
const rooms = new Map();

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const wrapAngle = (a) => Math.atan2(Math.sin(a), Math.cos(a));
const safeName = (v) => String(v || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 18);
function randomId(prefix = '') { return prefix + crypto.randomBytes(5).toString('hex'); }
function makeLoot(room, x, z, kind) {
  const id = randomId('l');
  room.loot.set(id, { id, x, z, kind, amount: kind === 'med' ? 28 : kind === 'armor' ? 35 : ['scrap','fiber','shard'].includes(kind) ? 1 : 24 });
}
function makeRoom(code) {
  const room = { code, players: new Map(), spectators: new Map(), bots: new Map(), loot: new Map(), vehicles: new Map(),
    npcs: new Map(NPC_DEFS.map(n => [n.id, { ...n }])), story: campaignFor(code), worldEvent: null,
    nextWorldEventAt: 0, weather: 'clear', active: false, createdAt: Date.now(),
    zone: { x: 0, z: 0, radius: 108, phase: 0 }, nextZoneAt: 0, tick: 0 };
  for (const v of VEHICLE_SPAWNS) room.vehicles.set(v.id, { ...v, speed: 0, occupant: null });
  for (let i = 0; i < BOT_COUNT; i++) {
    const a = i * Math.PI * 2 / BOT_COUNT;
    const r = 48 + (i % 4) * 8;
    room.bots.set(`bot-${i + 1}`, { id: `bot-${i + 1}`, name: `Rival ${String(i + 1).padStart(2, '0')}`,
      x: Math.cos(a) * r, z: Math.sin(a) * r, yaw: a + Math.PI, health: 100, armor: 20,
      alive: true, state: 'patrol', targetX: Math.cos(a + .6) * 70, targetZ: Math.sin(a + .6) * 70,
      nextAttack: 0, nextThink: 0, isBot: true });
  }
  for (let i = 0; i < 42; i++) {
    const a = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random()) * 94;
    const kind = ['ammo', 'ammo', 'med', 'armor'][i % 4];
    makeLoot(room, Math.cos(a) * r, Math.sin(a) * r, kind);
  }
  return room;
}
function getRoom(code) {
  if (!rooms.has(code)) rooms.set(code, makeRoom(code));
  return rooms.get(code);
}
function publicPlayer(p) {
  return { id: p.id, name: p.name, x: p.x, z: p.z, y: p.y, yaw: p.yaw, crouch: p.crouch,
    health: p.health, armor: p.armor, alive: p.alive, weapon: p.weapon, vehicleId: p.vehicleId, isBot: false };
}
function publicBot(p) {
  return { id: p.id, name: p.name, x: p.x, z: p.z, y: 0, yaw: p.yaw, crouch: false,
    health: p.health, armor: p.armor, alive: p.alive, weapon: 'rifle', isBot: true, state: p.state };
}
function lobby(room) {
  return { code: room.code, active: room.active, maxPlayers: MAX_PLAYERS,
    spectators: room.spectators.size,
    players: [...room.players.values()].map(p => ({ id: p.id, name: p.name, host: p.host, alive: p.alive })) };
}
function broadcastLobby(room) { io.to(room.code).emit('lobby', lobby(room)); }
function addFeed(room, text, color = 'normal') {
  io.to(room.code).emit('feed', { id: randomId('f'), text, color, at: Date.now() });
}
function worldEventState(room, recipient) {
  const e = room.worldEvent;
  if (!e) return null;
  const votes = {};
  for (const option of e.options) votes[option.key] = [...e.votes.values()].filter(v => v === option.key).length;
  return { id: e.id, kind: e.kind, title: e.title, prompt: e.prompt, options: e.options,
    active: e.active, endsAt: e.endsAt, result: e.result || '', votes, myVote: e.votes.get(recipient) || null };
}
function beginWorldEvent(room, now) {
  const template = EVENT_TEMPLATES[room.story.eventIndex++ % EVENT_TEMPLATES.length];
  room.worldEvent = { ...template, id: randomId('event-'), active: true, startedAt: now,
    endsAt: now + 30_000, votes: new Map(), result: '' };
  room.nextWorldEventAt = now + 82_000;
  io.to(room.code).emit('feed', { id: randomId('f'), text: `World event: ${template.title}`, color: 'storm', at: now });
}
function resolveWorldEvent(room) {
  const e = room.worldEvent;
  if (!e?.active) return;
  const tally = e.options.map(option => ({ option, count: [...e.votes.values()].filter(v => v === option.key).length }));
  tally.sort((a, b) => b.count - a.count || a.option.key.localeCompare(b.option.key));
  const winner = tally[0].option;
  e.active = false;
  room.story.lastChoice = `${e.kind}:${winner.key}`;
  if (e.kind === 'supply') {
    const spot = winner.key === 'A' ? { x: -35, z: -72 } : { x: 35, z: -29 };
    makeLoot(room, spot.x, spot.z, 'armor'); makeLoot(room, spot.x + 3, spot.z + 2, 'scrap');
    e.result = `The crew chose ${winner.label}. Supply crates appeared at the voted site.`;
  } else if (e.kind === 'transmission') {
    const spot = winner.key === 'A' ? { x: 4, z: 27 } : { x: -39, z: 4 };
    for (let i = 0; i < 3; i++) makeLoot(room, spot.x + i * 2, spot.z + (i % 2) * 2, 'shard');
    e.result = `The crew traced ${winner.label}. Three signal shards are now visible on the island.`;
  } else if (e.kind === 'weather') {
    room.weather = winner.key === 'A' ? 'clear' : 'signal-fog';
    room.story.weatherHistory.push(room.weather);
    e.result = `The island shifted to ${winner.label.toLowerCase()}.`;
  } else {
    const spot = winner.key === 'A' ? { x: 8, z: 31 } : { x: -9, z: -22 };
    for (let i = 0; i < 5; i++) makeLoot(room, spot.x + i * 1.8, spot.z + (i % 2) * 2, winner.key === 'A' ? 'shard' : 'scrap');
    e.result = `Community mission selected: ${winner.label}. Gather the marked resources and talk to an NPC.`;
  }
  io.to(room.code).emit('worldEventResult', { id: e.id, result: e.result, choice: winner.key });
  addFeed(room, e.result, 'storm');
}
function advanceWorldEvents(room, now) {
  if (!room.worldEvent && now >= room.nextWorldEventAt) beginWorldEvent(room, now);
  else if (room.worldEvent?.active && now >= room.worldEvent.endsAt) resolveWorldEvent(room);
}
function npcDialog(room, player, npc) {
  const mission = player.missions.relay;
  let dialogue = npc.id === 'mira'
    ? room.story.beaconUnlocked ? 'The beacon is steady now. The crew made that happen together.' : 'I found a broken beacon. Bring me two signal shards and I can map its next pulse.'
    : npc.id === 'tavi' ? 'I can turn scrap into field gear. Bring materials; I will keep the recipe simple.'
      : `The weather has shifted ${room.story.weatherHistory.length - 1} time(s). ${room.story.miraBranch ? `Mira's crew chose to ${room.story.miraBranch} the signal.` : 'The signal story is still unwritten.'}`;
  return { id: npc.id, name: npc.name, dialogue, mission: { ...mission }, branch: room.story.miraBranch,
    choices: npc.id === 'mira' ? [...(mission.status === 'ready' ? ['complete_relay'] : []), ...(mission.status === 'available' ? ['accept_relay'] : []), 'share_signal', 'keep_signal'] : ['ask_about_signal'] };
}
function applyDamage(target, amount) {
  const absorbed = Math.min(target.armor, Math.ceil(amount * 0.55));
  target.armor -= absorbed;
  target.health = Math.max(0, target.health - (amount - absorbed));
  if (target.health <= 0) target.alive = false;
}
function nearestTarget(room, shooter, aim, spec, spread) {
  let best = null, bestDistance = Infinity;
  const candidates = [...room.players.values(), ...room.bots.values()].filter(p => p.alive && p.id !== shooter.id);
  for (const p of candidates) {
    const dx = p.x - shooter.x, dz = p.z - shooter.z, d = Math.hypot(dx, dz);
    if (d > spec.range || d < 0.1) continue;
    const bearing = Math.atan2(dx, dz);
    const err = Math.abs(wrapAngle(bearing - aim));
    const allowed = spread + Math.atan2(p.isBot ? 1.4 : 1.05, d);
    if (err <= allowed && d < bestDistance && !blocked(shooter, p)) { best = p; bestDistance = d; }
  }
  return best;
}
function blocked(a, b) {
  for (const o of OBSTACLES) {
    const vx = b.x - a.x, vz = b.z - a.z;
    const t = clamp(((o.x - a.x) * vx + (o.z - a.z) * vz) / (vx * vx + vz * vz || 1), 0, 1);
    if (Math.hypot(a.x + vx * t - o.x, a.z + vz * t - o.z) < o.r * .72) return true;
  }
  return false;
}
function canStand(x, z, radius = 1.25) {
  if (Math.hypot(x, z) > WORLD_RADIUS - radius) return false;
  return !OBSTACLES.some(o => Math.hypot(x - o.x, z - o.z) < o.r + radius);
}
function aliveCount(room) {
  return [...room.players.values(), ...room.bots.values()].filter(p => p.alive).length;
}
function handleDeath(room, victim, killer) {
  if (victim.health > 0) return;
  if (victim.vehicleId) { const car = room.vehicles.get(victim.vehicleId); if (car) { car.occupant = null; car.speed = 0; } victim.vehicleId = null; }
  const lootKind = Math.random() < .45 ? 'armor' : 'ammo';
  makeLoot(room, victim.x, victim.z, lootKind);
  addFeed(room, `${killer.name} eliminated ${victim.name}`, victim.isBot ? 'bot' : 'kill');
  if (killer.id && room.players.has(killer.id)) killer.kills++;
}
function moveEntity(entity, dx, dz, dt, speed) {
  const len = Math.hypot(dx, dz);
  if (!len) return;
  const nx = entity.x + dx / len * speed * dt;
  const nz = entity.z + dz / len * speed * dt;
  if (canStand(nx, entity.z)) entity.x = nx;
  if (canStand(entity.x, nz)) entity.z = nz;
}
function simulateBots(room, now, dt) {
  for (const bot of room.bots.values()) {
    if (!bot.alive) continue;
    const targets = [...room.players.values()].filter(p => p.alive).map(p => ({ p, d: distance(bot, p) })).sort((a, b) => a.d - b.d);
    const closest = targets[0];
    if (now >= bot.nextThink) {
      bot.nextThink = now + 500 + Math.random() * 700;
      if (closest && closest.d < 58) { bot.state = closest.d < 24 ? 'attack' : 'chase'; bot.targetX = closest.p.x; bot.targetZ = closest.p.z; }
      else if (closest && closest.d > 58 && Math.random() < .18) bot.state = 'loot';
      else if (bot.state === 'loot' && Math.random() < .45) bot.state = 'patrol';
      if (bot.state === 'patrol' || bot.state === 'loot') {
        const loot = [...room.loot.values()].sort((a, b) => distance(bot, a) - distance(bot, b))[0];
        if (bot.state === 'loot' && loot) { bot.targetX = loot.x; bot.targetZ = loot.z; }
        else if (Math.hypot(bot.x - bot.targetX, bot.z - bot.targetZ) < 4) {
          const a = Math.random() * Math.PI * 2, r = 25 + Math.random() * 55;
          bot.targetX = clamp(bot.x + Math.cos(a) * r, -90, 90); bot.targetZ = clamp(bot.z + Math.sin(a) * r, -90, 90);
        }
      }
    }
    const speed = bot.state === 'chase' ? 4.2 : bot.state === 'loot' ? 2.4 : 1.5;
    const dx = bot.targetX - bot.x, dz = bot.targetZ - bot.z;
    if (Math.hypot(dx, dz) > 2) { bot.yaw = Math.atan2(dx, dz); moveEntity(bot, dx, dz, dt, speed); }
    if (bot.state === 'loot') {
      const item = [...room.loot.values()].find(l => distance(bot, l) < 2.2);
      if (item) { room.loot.delete(item.id); if (item.kind === 'med') bot.health = Math.min(100, bot.health + item.amount); else bot.armor = Math.min(100, bot.armor + item.amount); }
    }
    if (closest && closest.d < 27 && now >= bot.nextAttack && !blocked(bot, closest.p)) {
      bot.state = 'attack'; bot.nextAttack = now + 1550 + Math.random() * 500;
      const accuracy = closest.d <= 14 ? 0.70 : 0.50;
      const hit = Math.random() < accuracy;
      const missScale = hit ? 0 : 0.18 + Math.random() * 0.18;
      const impact = { x: closest.p.x + (Math.random() - .5) * missScale * closest.d,
        z: closest.p.z + (Math.random() - .5) * missScale * closest.d };
      const damage = hit ? 7 + Math.random() * 5 : 0;
      if (hit) { applyDamage(closest.p, damage); if (!closest.p.alive) handleDeath(room, closest.p, bot); }
      io.to(room.code).emit('botShot', { botId: bot.id, targetId: closest.p.id,
        from: { x: bot.x, z: bot.z }, to: impact, hit, damage, accuracy });
    }
  }
}
function advanceZone(room, now, dt) {
  if (!room.active) return;
  if (now >= room.nextZoneAt && room.zone.phase < 5) {
    room.zone.phase++;
    room.zone.radius = [108, 82, 60, 42, 27, 14][room.zone.phase];
    room.nextZoneAt = now + 45_000;
    addFeed(room, `Storm phase ${room.zone.phase}: safe zone is shrinking`, 'storm');
  }
  if (room.zone.phase > 0) {
    for (const p of [...room.players.values(), ...room.bots.values()]) {
      if (p.alive && Math.hypot(p.x - room.zone.x, p.z - room.zone.z) > room.zone.radius) {
        applyDamage(p, 5 * dt);
        if (!p.alive) handleDeath(room, p, { id: 'storm', name: 'Storm' });
      }
    }
  }
}
function stateFor(room, recipient) {
  const self = room.players.get(recipient);
  return { code: room.code, active: room.active, tick: room.tick,
    players: [...room.players.values()].map(publicPlayer), bots: [...room.bots.values()].map(publicBot),
    spectators: room.spectators.size, loot: [...room.loot.values()], vehicles: [...room.vehicles.values()].map(v => ({ ...v })),
    npcs: [...room.npcs.values()], story: room.story, weather: room.weather, worldEvent: worldEventState(room, recipient),
    zone: room.zone, alive: aliveCount(room),
    self: self ? { id: self.id, ackSeq: self.input.seq, health: self.health, armor: self.armor,
      alive: self.alive, weapon: self.weapon, ammo: self.ammo[self.weapon], reserve: self.reserve[self.weapon],
      kills: self.kills, y: self.y, vehicleId: self.vehicleId,
      vehicleSpeed: self.vehicleId ? room.vehicles.get(self.vehicleId)?.speed || 0 : 0,
      inventory: self.inventory, demoPoints: self.demoPoints, missions: self.missions } : null };
}
function stepRoom(room, now) {
  if (!room.active) return;
  const dt = TICK_MS / 1000; room.tick++;
  advanceWorldEvents(room, now);
  for (const p of room.players.values()) {
    if (!p.alive) continue;
    const input = p.input;
    if (p.vehicleId) {
      const car = room.vehicles.get(p.vehicleId);
      if (!car || car.occupant !== p.id) { p.vehicleId = null; continue; }
      const throttle = (input.forward ? 1 : 0) - (input.back ? 1 : 0);
      const steer = (input.right ? 1 : 0) - (input.left ? 1 : 0);
      if (throttle) car.speed += throttle * 52.5 * dt; else car.speed *= Math.pow(.985, dt * 20);
      car.speed = clamp(car.speed, -30, 80);
      if (Math.abs(car.speed) > .2) car.yaw -= steer * Math.sign(car.speed) * Math.min(1, Math.abs(car.speed) / 5) * 1.75 * dt;
      const nx = car.x + Math.sin(car.yaw) * car.speed * dt;
      const nz = car.z + Math.cos(car.yaw) * car.speed * dt;
      const carCollision = [...room.vehicles.values()].some(v => v.id !== car.id && Math.hypot(nx - v.x, nz - v.z) < 5.1);
      if (!carCollision && canStand(nx, nz, 4.3)) { car.x = nx; car.z = nz; }
      else car.speed *= -.12;
      p.x = car.x; p.z = car.z; p.y = 0; p.yaw = car.yaw; p.crouch = false;
      continue;
    }
    p.yaw = input.yaw;
    const f = (input.forward ? 1 : 0) - (input.back ? 1 : 0);
    const s = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    const len = Math.hypot(f, s) || 1;
    const speed = input.crouch ? 2.2 : input.sprint ? 11.2 : 6.4;
    const dx = (Math.sin(p.yaw) * f + Math.cos(p.yaw) * s) / len;
    const dz = (Math.cos(p.yaw) * f - Math.sin(p.yaw) * s) / len;
    moveEntity(p, dx, dz, dt, speed);
    p.crouch = input.crouch;
    if (input.jump && p.y <= 0.01) p.vy = 6.8;
    p.y = Math.max(0, p.y + p.vy * dt);
    p.vy = p.y > 0 ? p.vy - 17 * dt : 0;
  }
  simulateBots(room, now, dt);
  advanceZone(room, now, dt);
  if (room.players.size && aliveCount(room) <= 1) {
    room.active = false;
    const winner = [...room.players.values()].find(p => p.alive);
    addFeed(room, winner ? `${winner.name} wins the round` : 'Round over', 'win');
    broadcastLobby(room);
  }
  for (const id of [...room.players.keys(), ...room.spectators.keys()]) io.to(id).emit('state', stateFor(room, id));
}

io.on('connection', socket => {
  socket.data.lastInputAt = 0; socket.data.lastFireAt = 0; socket.data.lastSeq = -1; socket.data.room = null;
  socket.emit('welcome', { maxPlayers: MAX_PLAYERS, botCount: BOT_COUNT });
  socket.on('joinQueue', (body = {}, ack = () => {}) => {
    if (socket.data.room) return ack({ ok: false, error: 'Already in a room.' });
    const name = safeName(body.name);
    const requested = String(body.roomCode || 'STREAM-01').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 16) || 'STREAM-01';
    if (name.length < 2) return ack({ ok: false, error: 'Choose a name with at least 2 characters.' });
    const room = getRoom(requested);
    const role = body.role === 'spectator' ? 'spectator' : 'player';
    if (role === 'player' && room.active) return ack({ ok: false, error: 'That room is already in a match. Join as a spectator or try another room code.' });
    if (role === 'player' && room.players.size >= MAX_PLAYERS) return ack({ ok: false, error: 'Room is full. Try another room code.' });
    if (role === 'spectator' && room.spectators.size >= 100) return ack({ ok: false, error: 'Spectator room is full.' });
    const existing = [...room.players.values(), ...room.spectators.values()].some(p => p.name.toLowerCase() === name.toLowerCase());
    if (existing) return ack({ ok: false, error: 'That name is already in this room.' });
    if (role === 'spectator') {
      room.spectators.set(socket.id, { id: socket.id, name }); socket.data.room = room.code; socket.data.role = role; socket.join(room.code);
      ack({ ok: true, role, playerId: socket.id, code: room.code, host: false, lobby: lobby(room) }); broadcastLobby(room); return;
    }
    const p = { id: socket.id, name, x: (Math.random() - .5) * 12, z: (Math.random() - .5) * 12, y: 0, vy: 0,
      yaw: Math.random() * Math.PI * 2, crouch: false, health: 100, armor: 50, alive: true,
      host: room.players.size === 0, vehicleId: null, weapon: 'rifle', ammo: { rifle: 30, shotgun: 8, sniper: 5 },
      reserve: { rifle: 120, shotgun: 32, sniper: 20 }, kills: 0, reloading: false, input: { seq: -1, yaw: 0 },
      inventory: { scrap: 0, fiber: 0, shard: 0 }, demoPoints: 0, missions: { relay: { status: 'available', progress: 0, target: 2 } } };
    room.players.set(socket.id, p); socket.data.room = room.code; socket.data.role = role; socket.join(room.code);
    ack({ ok: true, role, playerId: socket.id, code: room.code, host: p.host, lobby: lobby(room) });
    broadcastLobby(room);
    addFeed(room, `${name} joined the drop`, 'join');
  });
  socket.on('startMatch', (_body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    if (!room || !p || !p.host) return ack({ ok: false, error: 'Only the room host can launch the match.' });
    if (room.active) return ack({ ok: false, error: 'Match already in progress.' });
    room.active = true; room.zone = { x: 0, z: 0, radius: 108, phase: 0 }; room.nextZoneAt = Date.now() + 45_000;
    room.weather = 'clear'; room.nextWorldEventAt = Date.now() + 18_000; room.worldEvent = null;
    for (const spawn of VEHICLE_SPAWNS) room.vehicles.set(spawn.id, { ...spawn, speed: 0, occupant: null });
    for (const player of room.players.values()) { player.health = 100; player.armor = 50; player.alive = true; player.kills = 0; player.vehicleId = null; player.x = (Math.random() - .5) * 16; player.z = (Math.random() - .5) * 16; }
    for (const bot of room.bots.values()) { bot.alive = true; bot.health = 100; bot.armor = 20; }
    ack({ ok: true }); broadcastLobby(room); addFeed(room, 'The drop has started. Good luck!', 'start');
  });
  socket.on('input', body => {
    const now = Date.now(), room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    if (!p || !room.active || !p.alive || !body || now - socket.data.lastInputAt < 25) return;
    socket.data.lastInputAt = now;
    const seq = Number(body.seq);
    if (!Number.isSafeInteger(seq) || seq <= socket.data.lastSeq || seq > socket.data.lastSeq + 1000) return;
    socket.data.lastSeq = seq;
    const requestedYaw = Number(body.yaw);
    const yawDelta = wrapAngle(requestedYaw - p.yaw);
    p.input = { seq, yaw: p.yaw + clamp(yawDelta, -.28, .28), forward: body.forward === true,
      back: body.back === true, left: body.left === true, right: body.right === true,
      jump: body.jump === true, crouch: body.crouch === true, sprint: body.sprint === true };
  });
  socket.on('vehicle', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    if (!room?.active || !p?.alive) return ack({ ok: false, error: 'You cannot drive right now.' });
    if (p.vehicleId) {
      const car = room.vehicles.get(p.vehicleId);
      if (!car || car.occupant !== p.id) { p.vehicleId = null; return ack({ ok: false }); }
      const side = { x: Math.cos(car.yaw) * 3.2, z: -Math.sin(car.yaw) * 3.2 };
      let x = car.x + side.x, z = car.z + side.z;
      if (!canStand(x, z)) { x = car.x - side.x; z = car.z - side.z; }
      if (!canStand(x, z)) return ack({ ok: false, error: 'There is no safe space to exit here.' });
      car.occupant = null; car.speed = 0; p.vehicleId = null; p.x = x; p.z = z; p.yaw = car.yaw;
      ack({ ok: true, vehicleId: null }); return;
    }
    const car = [...room.vehicles.values()].filter(v => !v.occupant).sort((a, b) => distance(p, a) - distance(p, b))[0];
    if (!car || distance(p, car) > 4.5) return ack({ ok: false, error: 'Move closer to an unoccupied vehicle.' });
    car.occupant = p.id; car.speed = 0; p.vehicleId = car.id; p.x = car.x; p.z = car.z; p.y = 0; p.yaw = car.yaw;
    ack({ ok: true, vehicleId: car.id });
  });
  socket.on('look', body => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    if (!p || !room.active || !Number.isFinite(body?.yaw)) return;
    const d = wrapAngle(body.yaw - p.yaw); p.yaw += clamp(d, -.16, .16);
  });
  socket.on('weapon', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id), w = WEAPONS[body?.weapon];
    if (!room?.active || !p?.alive || !w) return ack({ ok: false });
    p.weapon = body.weapon; ack({ ok: true, weapon: p.weapon, ammo: p.ammo[p.weapon] });
  });
  socket.on('fire', (body, ack = () => {}) => {
    const now = Date.now(), room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    if (!room?.active || !p?.alive || !body || now - socket.data.lastFireAt < (WEAPONS[p.weapon]?.rate || 800) - 8) return ack({ ok: false, reason: 'cooldown' });
    const spec = WEAPONS[p.weapon];
    if (!spec || p.ammo[p.weapon] <= 0) return ack({ ok: false, reason: 'empty' });
    const aim = Number(body.yaw);
    if (!Number.isFinite(aim) || Math.abs(wrapAngle(aim - p.yaw)) > .42) return ack({ ok: false, reason: 'invalid-aim' });
    socket.data.lastFireAt = now; p.ammo[p.weapon]--;
    const hits = new Map();
    for (let i = 0; i < spec.pellets; i++) {
      const jitter = (Math.random() - .5) * spec.spread;
      const target = nearestTarget(room, p, aim + jitter, spec, spec.spread * .34);
      if (target) hits.set(target, (hits.get(target) || 0) + 1);
    }
    let primaryHit = null;
    for (const [target, pellets] of hits) {
      if (!primaryHit || distance(p, target) < distance(p, primaryHit)) primaryHit = target;
      const damage = spec.damage * pellets;
      applyDamage(target, damage);
      const killed = !target.alive;
      if (killed) handleDeath(room, target, p);
      io.to(room.code).emit('impact', { shooter: p.id, target: target.id, damage, killed, weapon: p.weapon,
        from: { x: p.x, z: p.z }, to: { x: target.x, z: target.z } });
    }
    ack({ ok: true, ammo: p.ammo[p.weapon], hit: primaryHit ? { id: primaryHit.id, killed: !primaryHit.alive } : null });
  });
  socket.on('reload', (_body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    if (!room?.active || !p?.alive) return ack({ ok: false });
    const w = p.weapon, cap = WEAPONS[w].magazine;
    if (p.reloading) return ack({ ok: false });
    const need = cap - p.ammo[w], take = Math.min(need, p.reserve[w]);
    if (take <= 0) return ack({ ok: false });
    p.reloading = true;
    setTimeout(() => {
      p.reloading = false;
      if (!p.alive) return;
      const transfer = Math.min(cap - p.ammo[w], p.reserve[w], take);
      p.ammo[w] += transfer; p.reserve[w] -= transfer;
      ack({ ok: true, ammo: p.ammo[w], reserve: p.reserve[w] });
    }, 800);
  });
  socket.on('loot', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id), item = room?.loot.get(String(body?.id));
    if (!room?.active || !p?.alive || !item || distance(p, item) > 3.4) return ack({ ok: false });
    room.loot.delete(item.id);
    if (item.kind === 'med') p.health = Math.min(100, p.health + item.amount);
    if (item.kind === 'armor') p.armor = Math.min(100, p.armor + item.amount);
    if (item.kind === 'ammo') for (const key of Object.keys(p.reserve)) p.reserve[key] += item.amount;
    if (['scrap','fiber','shard'].includes(item.kind)) {
      p.inventory[item.kind] += item.amount;
      if (item.kind === 'shard' && p.missions.relay.status === 'active') {
        p.missions.relay.progress = Math.min(2, p.missions.relay.progress + item.amount);
        if (p.missions.relay.progress >= 2) { p.missions.relay.status = 'ready'; p.demoPoints += 20; }
      }
    }
    ack({ ok: true, kind: item.kind, amount: item.amount });
    addFeed(room, `${p.name} picked up ${item.kind}`, 'loot');
  });
  socket.on('eventVote', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), event = room?.worldEvent, vote = String(body?.choice || '');
    if (!room || !event?.active || !event.options.some(o => o.key === vote)) return ack({ ok: false, error: 'There is no open vote for that choice.' });
    event.votes.set(socket.id, vote); ack({ ok: true, choice: vote });
  });
  socket.on('npcInteract', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id), npc = room?.npcs.get(String(body?.npcId || ''));
    if (!room?.active || !p?.alive || !npc || distance(p, npc) > 5.2) return ack({ ok: false, error: 'Move closer to an available character.' });
    socket.emit('npcDialog', npcDialog(room, p, npc)); ack({ ok: true });
  });
  socket.on('npcChoice', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id), npc = room?.npcs.get(String(body?.npcId || '')), choice = String(body?.choice || '');
    if (!room?.active || !p?.alive || !npc || distance(p, npc) > 5.2) return ack({ ok: false, error: 'Move closer to the character first.' });
    if (npc.id === 'mira' && choice === 'accept_relay') { if (p.missions.relay.status === 'available') p.missions.relay.status = 'active'; }
    else if (npc.id === 'mira' && ['share_signal','keep_signal'].includes(choice)) room.story.miraBranch = choice === 'share_signal' ? 'share' : 'keep';
    else if (npc.id === 'mira' && choice === 'complete_relay' && p.missions.relay.status === 'ready') { p.missions.relay.status = 'complete'; room.story.completedMissions++; room.story.beaconUnlocked = true; }
    else if (!(npc.id !== 'mira' && choice === 'ask_about_signal')) return ack({ ok: false, error: 'That story choice is not available.' });
    ack({ ok: true, dialog: npcDialog(room, p, npc) });
  });
  socket.on('craft', (body, ack = () => {}) => {
    const room = rooms.get(socket.data.room), p = room?.players.get(socket.id);
    const recipes = { armor_patch: { cost: { scrap: 3, fiber: 1 }, effect: 'armor' }, field_medkit: { cost: { fiber: 2, shard: 1 }, effect: 'health' } };
    const recipe = recipes[String(body?.recipe || '')];
    if (!room?.active || !p?.alive || !recipe) return ack({ ok: false, error: 'Recipe unavailable.' });
    if (Object.entries(recipe.cost).some(([key, amount]) => p.inventory[key] < amount)) return ack({ ok: false, error: 'Not enough materials.' });
    for (const [key, amount] of Object.entries(recipe.cost)) p.inventory[key] -= amount;
    if (recipe.effect === 'armor') p.armor = Math.min(100, p.armor + 35); else p.health = Math.min(100, p.health + 35);
    ack({ ok: true, inventory: p.inventory, health: p.health, armor: p.armor });
  });
  socket.on('disconnect', () => {
    const code = socket.data.room, room = rooms.get(code);
    if (!room) return;
    const p = room.players.get(socket.id);
    if (p?.vehicleId) { const car = room.vehicles.get(p.vehicleId); if (car) { car.occupant = null; car.speed = 0; } }
    room.players.delete(socket.id); room.spectators.delete(socket.id);
    socket.data.room = null;
    if (room.players.size === 0 && room.spectators.size === 0) rooms.delete(code);
    else {
      if (p?.host) room.players.values().next().value.host = true;
      broadcastLobby(room); if (p) addFeed(room, `${p.name} left the drop`, 'join');
    }
  });
});

setInterval(() => { const now = Date.now(); for (const room of rooms.values()) stepRoom(room, now); }, TICK_MS).unref();
server.listen(PORT, HOST, () => console.log(`QuestCast arena prototype listening on http://${HOST}:${PORT}`));

