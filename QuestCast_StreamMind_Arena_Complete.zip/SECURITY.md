# Security and privacy controls

## Implemented

- Twitch Client Secret and tokens are server-side only.
- Twitch access/refresh tokens are encrypted at rest with Fernet (`TOKEN_ENCRYPTION_KEY`).
- OAuth authorization-code flow validates a random state value stored in an HttpOnly cookie.
- Creator session cookie is HttpOnly and SameSite=Lax; configure Secure cookies behind HTTPS.
- Workspace actions in LIVE require a valid creator session, except the OBS state endpoint when presented with a private overlay token.
- OBS token raw value is returned once; only SHA-256 hash is persisted. LIVE overlay token is sent in a request header rather than URL query parameters.
- EventSub webhook signatures use HMAC-SHA256 and timestamps are checked for replay age.
- Twitch message IDs, workspace event IDs, candidate fingerprints and quest-participant pairs are unique.
- Demo event endpoints are disabled in LIVE mode. Demo and Twitch workspaces use different keys.
- Pydantic bounds validate user input; React renders user strings as text.
- All outgoing Twitch chat messages are serialized to at most one per second; command cooldowns are persisted per user and command.
- Moderator grants are scoped to a creator workspace and matched against an authenticated Twitch user ID. Review endpoints permit approve/reject only; creator-only clip, quest mutation and moderator-management endpoints do not accept moderator workspace access.
- Overlay token creation rotates credentials by revoking prior tokens for that workspace.
- Candidate approval is required before clip attempt; clip metadata is stored only after Twitch confirms it.
- OpenAI API keys remain backend-only. Generated break activities are bounded and shown to the creator for review before being posted.
- Chat break voting consumes verified Twitch EventSub notifications only; raw chat text and voter IDs are not stored in poll records. Per-poll vote hashes and persistent cooldowns limit duplicate and rapid voting.
- Optional GIPHY search is browser-side as required by GIPHY's Search API. Its publishable client key is not a private credential; results use the `g` content rating and display GIPHY attribution.

## Required before public deployment

- HTTPS, `COOKIE_SECURE=true`, trusted reverse proxy configuration and strict host/origin policy.
- Production-grade rate limiting on all write endpoints and authentication attempts.
- Add a creator-facing overlay-token revoke control and audit log for moderator grants.
- Secret manager or deployment secret store; never bake `.env` into images.
- Database backups, restore drills, retention policy and access audit.
- Database-level concurrency guard for one active quest (a partial unique index is included for SQLite/PostgreSQL).
- Monitoring/alerting for OAuth refresh failures, EventSub reconnects, subscription revocations and clip API failures.
- Dependency scanning and pinned upgrade process.
- Review webhook raw-body handling and trusted public HTTPS endpoint before enabling webhook transport.

## Sensitive archive warning

Do not include `.env`, database files, `.git`, `venv`, `node_modules` or logs in shared archives. If a Client Secret or token is exposed in a shared/public location, revoke/rotate it immediately. The deliverable generated from the uploaded archive excludes `.env` and the bundled runtime database.
