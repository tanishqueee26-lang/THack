# QuestCast Architecture

## Product architecture

```mermaid
flowchart LR
  UI[React Creator Studio] --> API[FastAPI REST API]
  OBS[OBS Browser Source] --> API
  API --> DB[(SQLite / PostgreSQL)]
  API --> Q[StreamQuest domain]
  API --> C[ClipSynth scoring + review]
  API --> M[Community Memory]
  API --> AI[Optional copy provider]
  TW[Twitch OAuth / Helix] --> EV[EventSub WebSocket / Webhook]
  EV --> API
  Q --> DB
  C --> DB
  M --> DB
```

## Runtime boundaries

- **Frontend:** React + TypeScript + Vite. The browser never receives Twitch Client Secret, access token, refresh token or encryption key.
- **Backend:** FastAPI/Pydantic. Session resolution, mode enforcement, input validation, domain logic and Twitch API calls stay server-side.
- **Persistence:** SQLAlchemy. SQLite is the local default; PostgreSQL is supported with `psycopg` and Alembic.
- **Realtime:** Twitch EventSub WebSocket for LIVE event delivery; the OBS browser source polls the compact overlay-state endpoint every five seconds. The current domain logic is synchronous/lightweight; Redis/task worker is intentionally not introduced until long-running jobs justify it.
- **AI:** optional provider interface used only for creator-facing copy. Domain records, scores, quest progression and review decisions remain deterministic.

## Operating modes

`APP_MODE` supports:

- `simulation`: always uses the isolated `demo` workspace; generated data is labelled simulated; Twitch auth and real clip creation are disabled.
- `live`: uses only the authenticated Twitch workspace; missing credentials block Twitch login but never silently switch the mode.
- `auto`: legacy compatibility; incomplete Twitch config means simulation, complete config means LIVE mode. New deployments should explicitly choose `simulation` or `live`.

Live workspaces use `twitch:<local-user-id>` keys. Demo uses `demo`. Workspace events, candidates, quests, memory and participation are isolated by that key.

## Data model

| Table | Key fields | Purpose |
|---|---|---|
| `users` | Twitch ID, login, encrypted tokens, scopes | Creator identity and OAuth credentials |
| `sessions` | session ID, user ID | HttpOnly creator session |
| `events` | Twitch message ID, user ID, type, source, payload | Verified Twitch EventSub delivery log; unique message ID deduplicates retries |
| `health_events` | user ID, component, status, detail | Integration status history |
| `workspace_quests` | ID, workspace key, title, target, progress, status, stages/rules JSON | Creator-defined quest and lifecycle |
| `workspace_participation` | quest ID, participant ID, display name | One participation per viewer per quest (unique constraint) |
| `workspace_events` | event ID, workspace key, type, source, timestamp, simulated flag | Canonical activity feed for candidates, memory and overlay |
| `workspace_candidates` | ID, fingerprint, timestamps, score, confidence, reasons, review status, verified clip fields | Candidate/review/clip state; unique fingerprint dedupes identical windows |
| `workspace_memory` | ID, workspace key, kind, title, body, source ID, simulated flag | Milestones and creator-approved highlights |
| `workspace_overlay_credentials` | workspace key, token hash | Private OBS access token; only the raw token is returned once |

Important constraints:
- Only one quest may be active per workspace (activation service plus a partial unique index for SQLite and PostgreSQL; concurrency stress testing remains a deployment gate).
- `(quest_id, participant_id)` is unique.
- Twitch EventSub message IDs are unique in `events`.
- Workspace event IDs and candidate fingerprints are unique.
- Creator approval is required before attempting clip creation.

## Event flow

1. Twitch OAuth authorization-code flow stores tokens encrypted at rest and creates an HttpOnly session.
2. The backend validates the token and starts an EventSub WebSocket session. The welcome message supplies the session ID used for subscriptions.
3. EventSub notifications are deduplicated and persisted. Webhook transport validates HMAC signature and timestamp before accepting notifications.
4. The workspace processor records the verified event. Chat text is checked for `!join`, `!quest`, `!progress` and `!leaderboard`; moderator/broadcaster badges gate `!quest start` and `!quest pause`. Persistent per-user cooldowns prevent spam.
5. Quest progress and stage progress are committed. Crossing a stage threshold creates a milestone event and memory entry; completion records a chapter-complete event.
6. ClipSynth evaluates events in a rolling 60-second window using fixed weights. Overlapping hot windows are coalesced. Reasons are stored with the candidate.
7. Creator approves or rejects. Approved candidates become memory entries. A separate LIVE-only action calls Twitch Create Clip and then Get Clips; only verified clip IDs/URLs are stored.

## Candidate scoring

| Signal | Points |
|---|---:|
| Quest milestone | 5.0 |
| Streamer marker | 4.0 |
| Raid | 4.0 |
| Subscription | 2.0 |
| Follow | 1.0 |
| Quest participation | 0.6 |
| Chat message | 0.3 |

A candidate is created when the rolling 60-second total reaches 4.0. The UI shows per-signal contribution. `confidence = min(0.99, score / 12)` is only a normalized heuristic indicator, not a statistically calibrated probability. It does not determine approval.

## Clip semantics

A candidate is an event window, not video footage. After creator approval, QuestCast queries the creator's archive VODs, matches the candidate midpoint to a VOD using `created_at` and duration, and calculates a `vod_offset`. It calls Twitch Create Clip From VOD with a 30-second window and polls Get Clips for up to 60 seconds. A public clip URL is stored only after Twitch returns the requested clip ID. If no matching VOD is available or the offset is outside the VOD, the candidate remains visible with an explicit failure. The workflow requires `channel:manage:clips` or `editor:manage:clips`.

## API contract summary

The REST surface is grouped under `/api/workspace`:

- `GET /overview`, `GET /quests`, `POST /quests`
- `POST /quests/{id}/activate`, `POST /quests/{id}/pause`
- `POST /quests/{id}/participate` (SIMULATION only)
- `POST /demo/events` (SIMULATION only)
- `GET /candidates`, `POST /candidates/{id}/review`, `POST /candidates/{id}/clip`
- `GET /memory`, `GET /recap`
- `GET /overlay/state`, `POST /overlay/token`
- `POST /ai/suggestions`

All creator workspace endpoints resolve to `demo` in SIMULATION and require a valid creator session in LIVE. OBS in LIVE can use a hashed private overlay token. See OpenAPI at `/docs` for request/response schemas.

## Deployment

- Local: SQLite, `AUTO_CREATE_SCHEMA=true`, one FastAPI process, Vite dev server or nginx frontend.
- Deployment: PostgreSQL, `AUTO_CREATE_SCHEMA=false`, `alembic upgrade head`, TLS, secure cookies, database backups and monitored EventSub reconnection.
- Redis/background workers are not required for this local MVP. Add them when AI generation, media processing or long-running analytics become asynchronous workloads.


## Engagement, moderation and analytics

The event ingestion path feeds `backend.window.SlidingWindow` after the event is persisted. A bounded in-process cache is restored from the last three minutes of workspace events after restart; reads expose the trailing 60-second aggregate without running highlight detection. Candidate scoring remains event-driven and is not re-run by dashboard GETs. A multi-worker deployment must replace this per-process cache with a shared event stream/cache.

Twitch chat commands are processed only from verified EventSub chat notifications. Per-user/per-command cooldowns are stored in `workspace_chat_cooldowns`. `!join` records unique participation; informational commands read persisted progress and leaderboard state. `!quest start` / `!quest pause` require Twitch moderator or broadcaster badges. Replies are sent only when `user:write:chat` is actually granted.

Moderator grants are scoped to a creator workspace and matched against the moderator's authenticated Twitch user ID. Review endpoints accept a requested workspace key only after verifying that grant. This role can approve/reject candidates but does not inherit creator or clip permissions.

Peak-viewer analytics are based on once-per-minute Helix `/streams` samples while the channel is live. Event heatmap timestamps are UTC. No viewer sample means `null` peak viewers.


## ClipSynth VOD workflow and BotGuard

Approved candidates are aligned against the creator's Twitch archive videos using their recorded timestamps. QuestCast queries the creator's archive VODs, matches the candidate timestamp to a VOD's `created_at` and duration, computes a `vod_offset`, then calls Twitch `POST /helix/videos/clips` with a 30-second window. It polls `GET /helix/clips` and stores the clip URL only after the returned ID is present. Missing VODs and out-of-range timestamps remain explicit failures; QuestCast does not fabricate a clip or fall back to an unrelated timestamp.

BotGuard subscribes to Twitch `channel.suspicious_user.message` and `channel.suspicious_user.update` when `moderator:read:suspicious_users` is granted. It also uses privacy-minimizing rolling chat burst/repetition signals. The `workspace_bot_reviews` table stores the account, score, evidence labels, status and action audit. Raw chat text is not retained in workspace event payloads. Optional AI summarizes evidence only. The creator must explicitly confirm a channel ban; the endpoint requires `moderator:manage:banned_users` and calls Twitch's Ban User API. No automatic ban path exists.


Creator-marked moments are created through Twitch `POST /helix/streams/markers` with the broadcaster's user token and `channel:manage:broadcast`. The returned marker timestamp/position is recorded as a verified `stream.marker` event, feeding the same candidate scorer as milestones and community activity. Marker creation is unavailable if Twitch reports the stream offline or VOD disabled.

## Expansion architecture

The `backend.expansion` router extends the existing workspace without splitting the application into separate services. Economy state is ledger-backed (`exp_wallets`, `exp_economy_ledger`, `exp_inventory`, `exp_trades`). Story nodes form a directed graph through `parent_node_id` and `parent_choice_key`; each node stores its choices and one vote per viewer. The creator locks a branch; a child can only follow the exact branch selected by its parent.

Integration jobs (`exp_integration_jobs`) are durable status records, not proof that an external provider ran. Vision jobs remain blocked until a frame worker and multimodal model are configured. Publishing jobs wait for platform OAuth and a publishing worker. Gameplay actions are sandbox records unless a documented game adapter is installed. Twitch Extension requests use the Extension Helper JWT and the extension's base64 shared secret; viewer IDs are Twitch opaque IDs, not guessed account identities.

Quest progress can be auto-advanced only by creator-enabled fixed rules applied to verified, non-simulated Twitch EventSub records. The optional AI layer can explain or narrate recorded evidence but is not the authority for event truth, score calculation, or creator approval.
